<?php

$module = 'Ticket';
require_once('module/admin/setup.php');

showPage();

?>