<?php

include('module/_config/_header.php');

?>

<h1>Modules</h1>

<?php

include('module/_config/_footer.php');

?>