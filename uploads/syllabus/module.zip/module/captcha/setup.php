<?php

$module = 'Captcha';
require_once('module/admin/setup.php');

showPage();

?>