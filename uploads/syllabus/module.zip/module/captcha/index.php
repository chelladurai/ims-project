<?php

$_smode = 2;
require_once('module/auth.php');

require('module/captcha/default/index.php');

?>