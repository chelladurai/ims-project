<?php

function apiAccountGet($params)
{
	return opReadUser($params['id']);
}

function apiAccountGetByID($params)
{
	global $db;
	$uid = exValue($params['uid'], $params['id']);
	return (($uid > 0) ? $db->fetch1Row($db->select('Users LEFT JOIN AddInfo ON auID=uID', '*', 'aTelegramID=?', array($uid))) : array());
}

function apiAccountRegister($params)
{
	global $_GS, $db;
	if ($db->count('AddInfo', 'aTelegramID=?', array($params['uid'])))
		return false;

	//$login = exValue('User' . $params['uid'], $params['login']);
	$login = 'User' . $params['uid'];
	if ($params['ref'])
		$ruid = $db->fetch1($db->select('AddInfo', 'auID', 'aTelegramID=?', array($params['ref'])));
	$uid = $db->insert('Users', array(
		'uLogin' => $login,
		'uPass' => md5(uniqid() . $login),
		'uMail' => $login . '@' . $_GS['domain'],
		'uState' => 1,
		'uLevel' => 1,
		'uLang' => $params['lang'],
		'uMode' => '',
		'uTheme' => '',
		'uRef' => $ruid,
		'uSID' => md5($login . uniqid() . $ruid)
	));
	$db->insert('AddInfo', array(
		'auID' => $uid,
		'aName' => exValue($login, $params['name']),
		'aCTS' => timeToStamp(),
		'aCIP' => $_GS['client_ip'],
		'aTelegramID' => $params['uid']
	));

	return $uid;
}


function apiAccountSetRef($params)
{
	global $db;
	$uid = $db->fetch1($db->select('AddInfo', 'auID', 'aTelegramID=?', array($params['uid'])));
	if (!$uid)
		return 'uid_wrong';
	$ruid2 = $ruid = $db->fetch1($db->select('AddInfo', 'auID', 'aTelegramID=?', array($params['id'])));
	if (!$ruid)
		return 'ref_wrong';
	for ($i = 1; $i <= 4; $i++)
	if ($ruid2)
	{
		if ($ruid2 == $uid)
			return 'ref_wrong';
		$ruid2 = $db->fetch1($db->select('Users', 'uRef', 'uID=?d', array($ruid2)));
	}
	if (!$db->update('Users', array('uRef' => $ruid), '', 'uID=? and uRef=0', array($uid)))
		return 'ref_not_empty';
	return true;
}

?>