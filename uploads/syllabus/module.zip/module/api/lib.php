<?php
/*
global $_GS, $_cfg, $db;
session_id(md5($_GS['domain']));
$_smode = 2;
require_once('module/auth.php');
*/
function apiExec($params)
{
	botLog('--- API CALL ---');
	botLog($params);

	if (($method = $params['method']) and in_array($module = $params['module'], 
		array('account')))
	{
		require_once("$module.php");
		$method = 'api'. $module . $method;
		if (function_exists($method))
		{
			global $_GS;
			$_GS['lang'] = $params['lang'];
			$_GS['lang_dir'] = getLangDir();
			try
			{
				$result = $method($params);
			}
			catch (Exeception $e)
			{
				$result = $e->getMessage();
			}
		}
		else
			$result = 'unknown_mehod';
	}
	else
		$result = 'unknown_api';

	botLog($result);
	return $result;
}

?>