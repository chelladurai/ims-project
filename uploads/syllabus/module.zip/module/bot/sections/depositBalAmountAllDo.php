<?php

global $_currs;
$cid = $data['value'];
$sum = $_currs[$cid]['wBal'];

useLib('depo');
if (is_string(opDepoAdd(_uid(), $cid, $sum)))
	if (is_string($err = opDepoCreate(_uid(), $cid, $sum, 0, $session['depositBalPlan'])))
		return botError($err);

botExecute('zarabotok');
return botDone('depositsList');

?>