<?php

global $_currs, $_cfg;

useLib('balance');
$wnd = false;
$data['currs'] = array();
foreach ($_currs as $cid => $c)
if ($c['wBal'] * $_cfg['Bal_Rate' . $c['cCurr']] >= 0.1)
{
	$mode = valueIf($c['cCASHOUTMode'] == 2, true, 2);
	$udata = opDecodeUserCurrParams($c);
	if ($udata['acc'])
	{
		opOperCreate(_uid(), 'CASHOUT', $cid, $c['wBal'], array(), '', $mode);
	}
	else
	{
		$wnd = true;
		$data['currs'][] = $cid;
		botSay($c['cName'] . ': <b>' . $messages['errors']['wallet_not_defined'] . '</b>');
	}
}

botExecute('settings');
if ($wnd)
	return array('goto' => 'changeWallet');
return botDone('cashOut');

?>