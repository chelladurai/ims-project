<?php

botSet('confirm', array(
	'section' => 'depositBalAmountAllDo',
	'cid' => $data['value']
));

global $_currs;
$cid = $data['value'];
$lang[$section][1] .= $_currs[$cid]['cName'];

?>