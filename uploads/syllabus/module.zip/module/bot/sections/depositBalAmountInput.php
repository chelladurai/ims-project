<?php

if (!$itsData)
{
	botSet('depositBalPlan', $data['value']);
	botSet('section', $section);
	return false;
}

global $_currs;
$cid = $session['depositBalPSys'];
cn($request);
$sum = _z($request, $cid);

if ($sum <= 0)
	return botError('sum_wrong');
if ($sum > $_currs[$cid]['wBal'])
	return botError('low_bal1');

useLib('depo');
if (is_string(opDepoAdd(_uid(), $cid, $sum)))
	if (is_string($err = opDepoCreate(_uid(), $cid, $sum, 0, $session['depositBalPlan'])))
		return botError($err);

return botDone('depositsList');

?>