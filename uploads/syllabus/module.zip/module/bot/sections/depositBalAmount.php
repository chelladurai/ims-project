<?php

global $_currs;

botSet('depositBalPlan', $data['value']);
$cid = $session['depositBalPSys'];

$keys = array();
$keys[] = array(
	$lang['depositBalAmountAll'][0] . $_currs[$cid]['cName'] => array(
		'section' => 'depositBalAmountAll',
		'value' => $cid
	)
);
$keys[] = array(
	$lang['depositBalAmountInput'][0] => array(
		'section' => 'depositBalAmountInput'
	)
);

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);

?>