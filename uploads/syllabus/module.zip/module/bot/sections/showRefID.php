<?php

botSay($lang[$section][1]);

return array(
	'text' => "<b>$user_id</b>"
);

?>