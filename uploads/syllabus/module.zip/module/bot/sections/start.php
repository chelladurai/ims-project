<?php

//xAddToLog('--start--','bot3');
if ($itsData)
	return false;

botSet('history', array());

$ruid = intval(end(explode(' ', $request)));
$res = botCallAPI('account', 'register', array('uid' => $user_id, 'ref' => $ruid));

return $res;

?>