<?php

global $db, $_cfg, $_user, $_currs;

$d0 = timeToStamp(gmmktime(0, 0, 0));
$actref = '-';
$actsum = 0;

$uids = array(_uid());
for ($i = 1; $i <= 4; $i++)
	$uids = array_merge($uids, $db->fetchRows($db->select('Users', 'uID', 'uRef ?i', array($uids)), 1));
unset($uids[0]);

$a = $uids;

$zref = 0;
$list1 = $db->fetchRows($db->select('Opers', '*', 'oOper=? and ouID=?d and oTag ?i and oTS>=?', array('REF', _uid(), $a, $d0)));
foreach ($list1 as $o)
{
	$curr = $_currs[$o['ocID']]['cCurrID'];
	$zref += $z = $o['oSum'] * $_cfg["Bal_Rate$curr"];
}

$active = array();
$zdepo = 0;
$maxz = 0;
$maxuid = 0;
$list1 = $db->fetchRows($db->select('Deps', '*', 'duID ?i and dCTS>=?', array($a, $d0)));
foreach ($list1 as $d)
{
	$curr = $_currs[$d['dcID']]['cCurrID'];
	$zdepo += $z = $d['dZD'] * $_cfg["Bal_Rate$curr"];
	$active[$d['duID']] += $z;
	if ($active[$d['duID']] > $maxz)
		$maxz = $active[$maxuid = $d['duID']];
}
if ($maxuid)
{
	$actref = $db->fetch1($db->select('AddInfo', 'aTelegramID', 'auID=?d', array($maxuid)));
	$actsum = $maxz;
}

/*
return array(
	'text' => print_r($list, 1)
);
*/

$upref = opReadUser($_user['uRef']);
botFillTemplate(
	$section,
	array(
		'today' => gmdate('d/m/Y'),
		'zdepo' => _z($zdepo, 1),
		'zref' => _z($zref, 1),
		'n' => $db->count('Users LEFT JOIN AddInfo ON auID=uID', 'uRef ?i and aCTS>=?', array($uids, $d0)),
		'actref' => $actref,
		'actsum' => (($actsum > 0) ? '$' . _z($actsum, 1) : '-')
		
		
		
	)
	
	
	
);




?>

