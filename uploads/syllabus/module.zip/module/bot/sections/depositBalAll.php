<?php

global $_currs;

useLib('depo');
foreach ($_currs as $cid => $c)
{
	$sum = $c['wBal'];
	if (is_string(opDepoAdd(_uid(), $cid, $sum)))
		opDepoCreate(_uid(), $cid, $sum, 0, $session['depositBalPlan']);
}

return botDone('depositsList');

?>