<?php

botSet($data['name'], $data['value']);

?>