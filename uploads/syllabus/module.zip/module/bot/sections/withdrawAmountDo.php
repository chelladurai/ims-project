<?php

global $_currs;
$cid = $session['withdrawPSys'];
$sum = $data['value'];

useLib('balance');
$mode = valueIf($_currs[$cid]['cCASHOUTMode'] == 2, true, 2);
if (is_string($err = opOperCreate(_uid(), 'CASHOUT', $cid, $sum, array(), '', $mode)))
	return botError($err);

return botDone('cashOut');

?>