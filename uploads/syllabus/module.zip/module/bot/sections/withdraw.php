<?php

return array(
	'text' => $lang[$section][1],
	'goto' => 'withdrawPSys'
);

?>