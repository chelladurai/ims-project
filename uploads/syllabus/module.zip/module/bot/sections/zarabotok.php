<?php

global $db, $_cfg, $_currs;
//$_currs = $db->fetchIDRows($db->select('Currs LEFT JOIN Wallets ON wcID=cID and wuID=?d',
//	'*', 'cDisabled=0', array(_uid()), 'cID'), false, 'cID');
$s = '';
$d = '';
//foreach ($_currs as $cid => $c)
//	$s += _NL_ . _z($c['wBal'], $cid) . ' ' . $c['cName'];
foreach ($_currs as $cid => $c)
		$s .= _NL_ .  _z($c['wBal'], $cid) . ' BTC';

foreach ($_currs as $cid => $c)
        $d .= _NL_  . _z($c['wLock'], $cid) . ' BTC';
//botLog(_uid() . ':' . $s);
//

$sum  = $db->fetch1($db->select('Opers','SUM(oSum)','oOper="CALCIN" and oState=3 and ouID=?',array(_uid()))) ;
$sum = ($sum>0)? $sum : 0;

botSay($lang[$section][1]. "<b>$s</b>"); 
botSay($lang[$section][3]. "<b>$d</b>");
botSay($lang[$section][4]. "<b>$sum BTC</b>");

return array( 'goto'=>'depositsList');

?>