<?php

if (!$itsData)
{
	$usr = botCallAPI('account', 'getByID');
	$rusr = botCallAPI('account', 'get', array('id' => $usr['uRef']));
	if ($usr['uRef'])
		return array(
			'text' => $lang[$section][2] . '<b>' . $rusr['aTelegramID'] . '</b>'
		);
}
else
{
	if (!is_string($result = botCallAPI('account', 'setRef', array('id' => $request))))
		return botDone();
	return botError($result);
}

?>