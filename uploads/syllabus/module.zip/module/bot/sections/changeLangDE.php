<?php

botSet('lang', 'de');

require('module/bot/lang_de.php');
foreach ($lang as $s => &$l)
	if (!is_array($l))
		$l = array($l, $l);

return array('goto' => 'home');

?>