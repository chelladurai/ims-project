<?php

if (!$itsData)
	return false;

$cid = $session['depositPSys'];
cn($request);
$sum = _z($request, $cid);

if (($sum <= 0) or ($sum > 1000000))
	return botError('sum_wrong');

$data['value'] = $sum;

botExecute('depositLink');

return array('goto' => 'back');
/*
botExecute('back');

$result = botGetDepositLink($cid, $sum);
if (!is_array($result))
	return botError($result);
$keys = array(
	array(
		$lang[$section][0] => reset($result)
	)
);

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);
*/
?>