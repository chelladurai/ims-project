<?php

global $_currs;

useLib('balance');

$keys = array();
foreach ($_currs as $cid => $c)
//if (!$data['currs'] or in_array($cid, $data['currs']))
//if ($wps[$cid])
{
	$udata = opDecodeUserCurrParams($c);
	$keys[] = array(
		reset(explode(' ', $c['cName'])) . ': ' . $udata['acc'] => array(
			section => 'changeWalletInput',
			value => $cid,
			v => !empty($udata['acc'])
		)
	);
}

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);

?>