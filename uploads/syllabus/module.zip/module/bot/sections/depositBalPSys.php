<?php

global $db, $_currs;

$keys = array();
foreach ($_currs as $cid => $c)
	if ($c['wBal'] > 0)
		$keys[] = array(
			$c['cName'] . ': ' . _z($c['wBal'], $cid) => array(
				'section' => 'depositBalPlan',
				'value' => $cid
			)
		);
if (!$keys)
	return botError('no_funds');

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);

?>