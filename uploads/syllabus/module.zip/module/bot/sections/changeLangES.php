<?php

botSet('lang', 'es');

require('module/bot/lang_es.php');
foreach ($lang as $s => &$l)
	if (!is_array($l))
		$l = array($l, $l);

return array('goto' => 'home');

?>