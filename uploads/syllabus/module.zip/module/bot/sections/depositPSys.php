<?php

global $db, $_currs;

$keys = array();
foreach ($_currs as $cid => $c)
	//if ($c['cCurr'] == $data['value'])
		$keys[] = array(
			$c['cName']/* . ': ' . _z($c['wBal'], $cid)*/ => array(
				'section' => 'depositPlan',
				'value' => ($lastcid = $cid)
			)
		);
if (!$keys)
	return botError('no_funds');

if (count($keys) == 1)
{
	$data['value'] = $lastcid;
	return array('goto' => 'depositPlan');
}

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);

?>