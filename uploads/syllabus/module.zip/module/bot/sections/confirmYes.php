<?php

if ($a = $session['confirm'])
{
	botSet('confirm', NULL);

	$data['value'] = $a['cid'];

	//botExecute($a['section']);

	//botExecute('back');
	return array(
		'goto' => $a['section']
	);
}
else
	return array(
		'goto' => 'back'
	);

?>