<?php

botSet('lang', 'it');

require('module/bot/lang_it.php');
foreach ($lang as $s => &$l)
	if (!is_array($l))
		$l = array($l, $l);

return array('goto' => 'home');

?>