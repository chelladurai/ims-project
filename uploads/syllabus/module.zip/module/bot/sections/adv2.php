<?php

$banners = array(
	'120x120-small.gif',
	'125x125-small.gif',
	'160x600-small.gif',
	'468x60-small.gif',
	'728x90-small.gif'
);
$desc = array(
	'120x120',
	'125x125',
	'160x600',
	'468x60',
	'728x90'
);

foreach ($banners as $i => $f)
{
	$f = 'images/banner/' . $session['lang'] . '/small/' . $f;
	//$bot->sendPhoto($chat_id, $f);
	botSay("<b>{$lang[banner][0]} $desc[$i]</b>");
	$code = '&lt;a href="' . fullURL('?ref=' . $user_id) . '"&gt;' . _NL_ . 
		'&lt;img src="' . fullURL($f) . '"&gt;' . _NL_ . 
		'&lt;/a&gt;';
	botSay("<code>$code</code>");
}

return array('goto' => '');

?>