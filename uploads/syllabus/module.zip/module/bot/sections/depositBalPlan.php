<?php

botSet('depositBalPSys', $data['value']);

global $db, $_currs;

useLib('depo');
$plans = opDepoGetPlanList(_uid());

$keys = array();
foreach ($plans as $pid => $p)
		$keys[] = array(
			$p['pName']/* . ': ' . _z($c['wBal'], $cid)*/ => array(
				'section' => 'depositBalAmountInput',
				'value' => ($lastpid = $pid)
			)
		);

if (count($keys) == 1)
{
	$data['value'] = $lastpid;
	return array('goto' => 'depositBalAmountInput');
}

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);

?>