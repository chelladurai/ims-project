<?php

global $db, $_currs;

$oper = 'CASHOUT';

$from = intval($data['from']);
$list = $db->fetchRows($db->select('Opers', '*', 'ouID=?d and oOper=? and oState=3', 
	array(_uid(), $oper), 'oID desc', "$from, 10"));

$text = '';
foreach ($list as $o)
	$text .= _NL_ . 
		gmdate('d.m.y | H:i', stampToTime($o['oTS'])) . ' | ' . 
		$_currs[$o['ocID']]['cName'] . ' | ' .
		botCurr($o['ocID']) . _z($o['oSum'], $o['ocID']);

$keys = array();
if (count($list) == 10)
	$keys[] = array(
		$lang['nextPage'][0] => array(
			'section' => $section,
			'from' => $from + 10
		)
	);

return array(
	'text' => $lang[$section][1] . $text,
	'keys' => $keys
);

?>