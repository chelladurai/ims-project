<?php

if ($itsData)
	return false;

global $db, $_cfg, $_user, $_currs;

$uids = array(_uid());
for ($i = 1; $i <= 3; $i++)
	$uids = array_merge($uids, $db->fetchRows($db->select('Users', 'uID', 'uRef ?i', array($uids)), 1));
unset($uids[0]);

$a = $uids;

$zref = 0;
$list1 = $db->fetchRows($db->select('Opers', '*', 'oOper=? and ouID=?d and oTag ?i', array('REF', _uid(), $a)));
foreach ($list1 as $o)
{
	$curr = $_currs[$o['ocID']]['cCurrID'];
	$zref += $z = $o['oSum'] /** $_cfg["Bal_Rate$curr"]*/;
}

$active = array();
$zdepo = 0;
$list1 = $db->fetchRows($db->select('Deps', '*', 'duID ?i', array($a)));
foreach ($list1 as $d)
{
	$active[$d['duID']]++;
	$curr = $_currs[$d['dcID']]['cCurrID'];
	$zdepo += $z = $d['dZD'] /** $_cfg["Bal_Rate$curr"]*/;
}
$active = count($active);
/*
return array(
	'text' => print_r($list, 1)
);
*/

$upref = opReadUser($_user['uRef']);
botFillTemplate(
	$section,
	array(
		'upref' => $upref['aTelegramID'],
		'reflink' => $root_url.'?ref=' . $user_id,
		'active' => $active,
		'nonactive' => count($uids) - $active, 
		'zdepo' => $zdepo,
		'zref' => $zref)
);

?>