<?php

botSet('confirm', array(
	'section' => 'withdrawAllDo'
));

?>