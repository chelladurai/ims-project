<?php

global $db, $_currs;

$list = $db->fetchRows($db->select('Deps LEFT JOIN Plans ON pID=dpID', '*', 'duID=?d', array(_uid())));

$keys = array();
foreach ($list as $d) {
     if ($d['dState'] == 1) {
         botSay(_z($d['dZD'], $d['dcID']) . 'BTC  | ' . $d['pName'] . '  | ' . floor(($d['pNPer'] - $d['dNPer']) / 6) . $lang[$section][1]);
     }
     else {
         ;
     }
}


return array('');

?>