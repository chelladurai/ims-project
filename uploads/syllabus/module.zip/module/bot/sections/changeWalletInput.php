<?php

global $db, $_cfg, $_currs;

if (!$itsData)
{
	if ($_cfg['Bal_LockWallets'] and $data['v'])
		return botError('wallet_not_empty');
	botSet('changeWallet', $data['value']);
	$lang['changeWalletInput'][1] .= $_currs[$data['value']]['cName'];
}
else
{
	include_once('lib/psys.php');
	useLib('balance');
	$t = time();
if ($cid = $session['changeWallet'])
{
	$c = $_currs[$cid];
	$a = opDecodeUserCurrParams($c);
	if ($_cfg['Bal_LockWallets'] and $a['acc'])
		//if (count($pss) == 1)
			return botError('wallet_not_empty');
		//else
		//	continue;
	$pf = getPayFields($c['cCID']);
	if ($pf['acc'][1])
		if (!preg_match('/^' . $pf['acc'][1] . '$/', $request))
			return botError('format_wrong');
	$key = $cid . _uid() . $t;
	$p = array('acc' => $request);
	$a = array(
		'wParams' => encodeArrayToStr($p, $key),
		'wMTS' => timetostamp($t)
	);
	if (!$c['wcID'])
	{
		$a['wcID'] = $cid;
		$a['wuID'] = _uid();
		$db->insert('Wallets', $a);
	}
	else
		$db->update('Wallets', $a, '', 'wcID=?d and wuID=?d', array($cid, _uid()));
}
	return botDone();
}

?>