<?php

botSet('confirm', NULL);

return array(
	'goto' => 'back'
);

?>