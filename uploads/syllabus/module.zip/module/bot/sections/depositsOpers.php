<?php

global $db, $_currs;

$from = intval($data['from']);
$list = $db->fetchRows($db->select('Opers', '*', 'ouID=?d and oMemo=?', 
	array(_uid(), '#' . $data['value']), 'oID desc', "$from, 10"));

$text = '';
foreach ($list as $o)
	$text .= _NL_ . 
		gmdate('d.m.y | H:i', stampToTime($o['oTS'])) . ' | ' . 
		botCurr($o['ocID']) . _z($o['oSum'], $o['ocID']) . ' | ' .
		$opers[$o['oOper']];

$keys = array();
if (count($list) == 10)
	$keys[] = array(
		$lang[$section][0] => array(
			'section' => 'depositsOpers',
			'value' => $data['value'],
			'from' => $from + 10
		)
	);

return array(
	'text' => valueIf(
		!$from, 
		$lang[$section][1] . $_currs[$data['d'][0]]['cName'] . ' ' . botCurr($data['d'][0]) . $data['d'][1] . ':'
	) . $text,
	'keys' => $keys
);

?>