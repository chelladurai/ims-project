<?php

botSet('depositPlan', $data['value']);
$cid = $session['depositPSys'];
global $_currs;
$curr = $_currs[$cid]['cCurr'];

$amounts = array(
	'USD' => array(
		array(20, 30, 50),
		array(100, 200, 300),
		array(500, 700, 1000),
	),
	'EUR' => array(
		array(10, 15, 25),
		array(50, 100, 250),
		array(500, 1000, 2000),
		array(3000, 5000, 10000)
	),
	'RUB' => array(
		array(600, 1000, 1500),
		array(2000, 5000, 10000),
		array(15000, 20000, 35000),
		array(50000, 75000, 100000)
	),
	'BTC' => array(
		array(0.02, 0.03, 0.05),
		array(0.1, 0.2, 0.3),
		array(0.5, 0.7, 1.0),
	),
	'LTC' => array(
		array(4, 5, 10),
		array(20, 30, 50),
		array(60, 80, 100),
	),
	'ETH' => array(
		array(0.5, 1, 3),
		array(10, 15, 20),
		array(25, 30, 40),
	)
);

$keys = array();
foreach ($amounts[$curr] as $r)
{
	$row = array();
	foreach ($r as $z)
		$row[botCurr($cid) . $z] = array(
			'section' => 'depositLink',
			'value' => $z
		);
	$keys[] = $row;
}
$keys[] = array(
	$lang['depositAmountInput'][0] => array(
		'section' => 'depositAmountInput'
	)
);
/*
$keys[] = array(
	$lang['depositBal'][0] => array(
		'section' => 'depositBalAmount',
		'value' => $data['value']
	)
);
*/
return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);


?>
