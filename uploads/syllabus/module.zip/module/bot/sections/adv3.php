<?php

$banners = array(
	'120x600.png',
	'240x400.png',
	'250x250.png',
	'300x250.png',
	'300x600.png',
	'320x100.png',
	'336x280.png'
);

foreach ($banners as $f)
{
	$f = 'images/banner/' . $session['lang'] . '/context/' . $f;
	$bot->sendPhoto($chat_id, $f);
}

return array('goto' => '');

?>