<?php

global $db, $_currs;

$text = '';
foreach ($_currs as $cid => $c)
	if ($c['wBal'] > 0)
		$text .= _NL_ . $c['cName'] . ': ' . _z($c['wBal'], $cid);

if (!$text)
	return botError('no_funds');

$keys = array(
	array(
		$lang['depositBalAll'][0] => array(
			'section' => 'depositBalAll',
		)
	)
);

return array(
	'text' => $lang[$section][1] . $text,
	'keys' => $keys
);

?>