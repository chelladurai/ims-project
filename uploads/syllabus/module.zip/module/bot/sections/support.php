<?php
/*
$keys = array(
	array(
		$lang[$section][0] => $lang[$section][2]
	)
);

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);
*/

botFillTemplate(
	$section,
	array(
		'uid' => $user_id
	)
);

?>