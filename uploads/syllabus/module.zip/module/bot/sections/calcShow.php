<?php

$sum = $data['value'];
$cid = $data['cid'];
$page = $data['page'];

$d = gmmktime(0, 0, 0) + (1 + $page * 10) * HS2_UNIX_DAY;
$z = (1 + $page * 9) * calcPerc($sum, 17.5, 6);
$text = '';
for ($i = 1; $i <= 9; $i++)
{
	$text .= _NL_ . 
		gmdate('d.m.y', $d) . ' | ' .
		$i . '. | ' .
		botCurr($cid) . _z(calcPerc($sum, 17.5, 6), $cid) . ' | ' .
		botCurr($cid) . _z($z, $cid);
	$z += calcPerc($sum, 17.5, 6);
	$d += HS2_UNIX_DAY;
}

if ($page)
{
	$lang[$section][1] = '';
}
else
botFillTemplate(
	$section,
	array(
		'sum' => botCurr($cid) . _z($sum, $cid),
		'sum2' => botCurr($cid) . _z(9 * calcPerc($sum, 17.5), $cid)
	)
);

$keys = array();
/*
if ($page < 4)
$keys[] = array(
	$lang['nextPage'][0] => array(
		'section' => $section,
		'value' => $sum,
		'cid' => $data['cid'],
		'page' => $page + 1
	)
);
*/
return array(
	'text' => $lang[$section][1] . $text,
	'keys' => $keys
);

?>