<?php

@array_pop($session['history']);
return array('goto' => end($session['history']));

?>