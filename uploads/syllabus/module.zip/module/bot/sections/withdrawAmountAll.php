<?php

global $_currs;
$cid = $data['value'];
$sum = $_currs[$cid]['wBal'];

useLib('balance');
$mode = valueIf($_currs[$cid]['cCASHOUTMode'] == 2, true, 2);
if (is_string($err = opOperCreate(_uid(), 'CASHOUT', $cid, $sum, array(), '', $mode)))
	return botError($err);

return botDone('cashOut');

?>