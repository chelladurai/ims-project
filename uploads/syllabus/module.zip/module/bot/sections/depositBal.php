<?php

global $db, $_cfg, $_currs;
$z = 0;
foreach ($_currs as $cid => $c)
	$z += $c['wBal'] * $_cfg["Bal_Rate" . $c['cCurr']];

botFillTemplate(
	$section,
	array(
		'z' => _z($z, 1)
	)
);

return array(
	'text' => $lang[$section][1],
	'goto' => 'depositBalPSys'
);

?>