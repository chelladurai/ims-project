<?php

global $db, $_cfg, $_currs;

$level = 4;
$from = intval($data['from']);

$uids = array(_uid());
for ($i = 1; $i <= $level; $i++)
	$uids = $db->fetchRows($db->select('Users', 'uID', 'uRef ?i', array($uids)), 1);

$list = $db->fetchIDRows($db->select('Users LEFT JOIN AddInfo ON auID=uID', 
		'uID, uLogin, aCTS', 'uID ?i', array($uids), 'aCTS desc', "$from, 10"), false, 'uID');

$a = valueIf(!$from, $uids, array_keys($list));

$zref = 0;
$list1 = $db->fetchRows($db->select('Opers', '*', 'oOper=? and ouID=?d and oTag ?i', array('REF', _uid(), $a)));
foreach ($list1 as $o)
{
	$curr = $_currs[$o['ocID']]['cCurrID'];
	$zref += $z = $o['oSum'] * $_cfg["Bal_Rate$curr"];
	if ($list[$o['oTag']])
		$list[$o['oTag']]['ZRef'] += $z;
}

$active = array();
$zdepo = 0;
$list1 = $db->fetchRows($db->select('Deps', '*', 'duID ?i', array($a)));
foreach ($list1 as $d)
{
	$active[$d['duID']]++;
	$curr = $_currs[$d['dcID']]['cCurrID'];
	$zdepo += $z = $d['dZD'] * $_cfg["Bal_Rate$curr"];
	if ($list[$d['duID']])
		$list[$d['duID']]['ZDepo'] += $z;
}
$active = count($active);
/*
return array(
	'text' => print_r($section, 1)
);
*/
$text = '';
foreach ($list as $u)
	$text .= _NL_ . 
		timeToStr(stampToTime($u['aCTS'])) . ' | ' . 
		$u['uLogin'] . ' | ' .
		_z($u['ZDepo'], 1) . ' | ' .
		_z($u['ZRef'], 1);

$keys = array();
if (count($list) == 10)
	$keys[] = array(
		$lang['nextPage'][0] => array(
			'section' => $section,
			'from' => $from + 10
		)
	);

botFillTemplate(
	$section,
	array(
		'active' => $active,
		'nonactive' => count($uids) - $active, 
		'zdepo' => _z($zdepo, 1),
		'zref' => _z($zref, 1)
	)
);

return array(
	'text' => valueIf(!$from, $lang[$section][1]) . $text,
	'keys' => $keys
);

?>