<?php

botSet('lang', 'ru');

require('module/bot/lang_ru.php');
foreach ($lang as $s => &$l)
	if (!is_array($l))
		$l = array($l, $l);

return array('goto' => 'home');

?>