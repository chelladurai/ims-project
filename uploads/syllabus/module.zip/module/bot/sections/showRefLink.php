<?php

global $_GS;

$refLink = $_GS['root_url'].'?ref=' . $user_id;
//botSay($lang['ref_site'][0]);
//botSay("<code>$refLink</code>");

botSay($lang['ref_tele'][0]);
return array(
	'text' => "<code>https://telegram.me/BakeMiningBot/?start=$user_id</code>"
);

?>
