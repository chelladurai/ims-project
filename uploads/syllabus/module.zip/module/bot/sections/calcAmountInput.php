<?php

if (!$itsData)
{
	botSet('section', $section);
	return false;
}

$cid = $session['calc'];
cn($request);
$sum = _z($request, $cid);

if (($sum <= 0) or ($sum > 1000000))
	return botError('sum_wrong');

$data['value'] = $sum;
$data['cid'] = $cid;

//botExecute('calcShow');

return array('goto' => 'calcShow');

?>