<?php

global $_currs;

useLib('balance');
$udata = opDecodeUserCurrParams($_currs[$data['value']]);
if (!$udata['acc'])
{
	botSet('changeWallet', $data['value']);
	return botError('wallet_not_defined', 'changeWalletInput');
}

botSet('withdrawPSys', $data['value']);

$amounts = array(
	'USD' => array(
		array(10, 15, 25),
		array(50, 100, 250),
		array(500, 1000, 2000),
		array(3000, 5000, 10000)
	),
	'EUR' => array(
		array(10, 15, 25),
		array(50, 100, 250),
		array(500, 1000, 2000),
		array(3000, 5000, 10000)
	),
	'RUB' => array(
		array(600, 1000, 1500),
		array(2000, 5000, 10000),
		array(15000, 20000, 35000),
		array(50000, 75000, 100000)
	),
	'BTC' => array(
		array(0.02, 0.05, 0.1),
		array(0.2, 0.5, 1.0),
		array(1.5, 2.0, 3.0),
		array(5.0, 10.0, 20.0)
	)
);

$keys = array();
foreach ($amounts[$_currs[$data['value']]['cCurr']] as $r)
{
	$row = array();
	foreach ($r as $z)
		$row[botCurr($data['value']) . $z] = array(
			'section' => 'withdrawAmountDo',
			'value' => $z
		);
	$keys[] = $row;
}
$keys[] = array(
	$lang['withdrawAmountInput'][0] => array(
		'section' => 'withdrawAmountInput'
	)
);
$keys[] = array(
	$lang['depositBalAmountAll'][0] /*. $_currs[$data['value']]['cName']*/ => array(
		'section' => 'depositBalAmountAll',
		'value' => $data['value']
	)
);
$keys[] = array(
	$lang['withdrawAmountAll'][0] . $_currs[$data['value']]['cName'] => array(
		'section' => 'withdrawAmountAll',
		'value' => $data['value']
	)
);

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);

?>