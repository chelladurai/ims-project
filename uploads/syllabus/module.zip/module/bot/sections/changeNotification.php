<?php

global $db, $_user;

if ($op = $data['op'])
{

$_user["aNf$op"] = $data['value'];
$db->update('AddInfo', array("aNf$op" => $data['value']), '', 'auID=?d', array(_uid()));

$keys = array();
foreach ($lang['changeNotification'][2] as $op => $s)
{
	$v = ($_user["aNf$op"] != 0);
	$keys[] = array(
		$lang['checkbox'][(int)$v] . " " . $s  => array(
			'section' => $section,
			'op' => $op,
			'value' => !$v
		)
	);
}

$bot->editKeys($chat_id, $message_id, $keys);

return array('goto' => '');

}
else
{

$keys = array();
foreach ($lang['changeNotification'][2] as $op => $s)
{
	$v = ($_user["aNf$op"] != 0);
	$keys[] = array(
		$lang['checkbox'][(int)$v] . " " . $s  => array(
			'section' => $section,
			'op' => $op,
			'value' => !$v
		)
	);
}

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);

}

?>