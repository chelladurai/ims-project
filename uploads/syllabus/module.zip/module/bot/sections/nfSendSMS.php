<?php

$keys = array(
	array(
		'[ '.($data['value'] ? '0' : 'X').' ]   Рассылка SMS' => array(
			section => 'nfSendSMS',
			value => intval(!$data['value'])
		)
	)
);
$bot->editKeys($chat_id, $message_id, $keys);

?>