<?php

global $db, $_currs;

$oper = 'REF';

$from = intval($data['from']);
$list = $db->fetchRows($db->select('Opers', '*', 'ouID=?d and oOper=? and oState=3 and (oMemo ?%)', 
	array(_uid(), $oper, '(from accrual)'), 'oID desc', "$from, 10"));

$text = '';
foreach ($list as $o)
	$text .= _NL_ . 
		gmdate('d.m.y | H:i', stampToTime($o['oTS'])) . ' | ' . 
		$_currs[$o['ocID']]['cName'] . ' | ' .
		botCurr($o['ocID']) . _z($o['oSum'], $o['ocID']) . ' | ' .
		substr($o['oMemo'], 0, -15);

$keys = array();
if (count($list) == 10)
	$keys[] = array(
		$lang['nextPage'][0] => array(
			'section' => $section,
			'from' => $from + 10
		)
	);

return array(
	'text' => $lang[$section][1] . $text,
	'keys' => $keys
);

?>