<?php

if (!$itsData)
	return false;

global $_currs;
$cid = $session['withdrawPSys'];
cn($request);
$sum = _z($request, $cid);

if ($sum <= 0)
	return botError('sum_wrong');
if ($sum > $_currs[$cid]['wBal'])
	return botError('low_bal1');

useLib('balance');
$mode = valueIf($_currs[$cid]['cCASHOUTMode'] == 2, true, 2);
if (is_string($err = opOperCreate(_uid(), 'CASHOUT', $cid, $sum, array(), '', $mode)))
	return botError($err);

return botDone('cashOut');

?>