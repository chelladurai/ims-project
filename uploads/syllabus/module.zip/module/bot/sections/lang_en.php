﻿<?php

$lang = array(
	start => "\xF0\x9F\x8F\x81" . ' Welcome! My name is Indi. I was created to help you receive profit from your investments. I speak only english but I'm learning other languages at the moment. ' . _NL_ .'Choose language' . ,
    back => "\xE2\xAC\x85" . ' Back',
    home => array("\xF0\x9F\x8F\xA0".' Main menu', 'Main menu'),
    nextPage => 'Show more',

    confirm => 'Confirm operation',
    confirmYes => array("\xE2\x9C\x85" . ' Confirm!', 'Operation  confirmed'),
    confirmNo => array("\xE2\x9D\x8C" . ' Cancel', 'Operation canceled'),

    zarabotok => array("\xF0\x9F\x92\xB0" . ' Balance', 'Funds on your balance: #s#', 'There is no funds on your balance. Click -Add funds- button'),
    depositBal => array("\xE2\x86\xA9" . ' Create deposit from balance', 'I will create new deposit from your balance'),
    depositBalPSys => array('Select payment system', 'Select payment system'),
	depositBalPlan => array('Selecting plan', 'Select plan'),
    depositBalAmount => array('What amount?', 'What amount to charge?'),
  //  depositBalAmountAll => array("\xE2\x86\xA9" . ' Reinvest all funds?'),
    depositBalAmountInput => array("\xF0\x9F\x92\xB2" . ' Set amount manual', 'Fill amount'),
    depositBalAllAsk => array("\xF0\x9F\x98\x8E" . ' Reinvest all', 'Reinvest all available funds'),
    depositBalAll => 'Reinvest all',
    depositPSys => array("\xE2\x9E\x95" . ' Add funds', 'Select payment system'),
    depositAmount => array('Select amount', 'How much you want to invest?'),
    depositAmountInput => array("\xF0\x9F\x92\xB2" . ' Enter the amount of manual', 'Enter the amount'),
    depositLink => array('Pay', 'For add funds #sum# follow to the link:'),
    withdraw => array("\xE2\x9E\x96" . ' Withdraw', "\xF0\x9F\x93\xA4" . ' Withdrawal of funds to the wallet'),
    withdrawPSys => "\xF0\x9F\x92\xB3" . ' Select payment system',
    withdrawAll => 'Withdraw all',
    withdrawAmount => 'Select amount',
    withdrawAmountAll => "\xE2\x86\x97" . ' Withdraw all to the wallet ',
    withdrawAmountInput => array("\xF0\x9F\x92\xB2" . ' Enter the amount for  manual', 'Fill amount'),
    deposits => array("\xF0\x9F\x92\xBC" . ' My deposits', ''),
    depositsList => 'Active deposit',
    depositsOpers => array('View another 10 operations', 'Deposit '),

    referral => array("\xF0\x9F\x91\xA5" . ' Referral system',
        'In your team #active# is #nonactive# users, wich invested $#zdepo#' . _NL_ .
        'You ref. bonus $#zref#'
    ),
    ref1 => array("\x31\xE2\x83\xA3" . ' 1-st level',
        '<b>1 level</b>' . _NL_ .
        'Active / Inactive: #active# / #nonactive#' . _NL_ .
        'Ivested funds: $#zdepo#' . _NL_ .
        'The affiliate bonus: $#zref#'
    ),
    ref2 => array("\x32\xE2\x83\xA3" . ' 2-nd level',
        '<b>2 level</b>' . _NL_ .
        'Active / Inactive: #active# / #nonactive#' . _NL_ .
        'Ivested funds: $#zdepo#' . _NL_ .
        'The affiliate bonus: $#zref#'
    ),
    ref3 => array("\x33\xE2\x83\xA3" . ' 3-d level',
        '<b>3 level</b>' . _NL_ .
        'Active / Inactive: #active# / #nonactive#' . _NL_ .
        'Ivested funds: $#zdepo#' . _NL_ .
        'The affiliate bonus: $#zref#'
    ),
    showRefLink => array("\xF0\x9F\x94\x97" . ' Your ref-link', 'Your ref-link'),
    changeUpRef => array("\xF0\x9F\x91\xA4" . ' Your inviter',
        'You have not specified inviter.' . _NL_ . 'Specify the user ID who invited you:',
        'You invited: '
    ),

    settings => array("\xF0\x9F\x94\xA7" . ' Settings', 'Configuring your account settings'),
    changeWallet => array("\xF0\x9F\x94\x90" . ' Payment details', 'Indicate the details of their wallets'),
    changeWalletInput => 'Set Wallet ',
    changeLang => array("\xF0\x9F\x8C\x90" . ' Change language', 'Choose language' . _NL_ . 'Choose your language'),

    operations => array("\xF0\x9F\x94\x80" . ' My Operations', 'View a list of your transactions by type'),
    cashIn => array("\xF0\x9F\x93\xA5" . ' Add funds', 'Add funds operation:'),
    cashOut => array("\xF0\x9F\x93\xA4" . ' Withdraw', 'Withdrawal:'),
    refD => array("\xF0\x9F\x95\x90" . ' Ref.bonus', 'Affiliate bonus:'),

    ref_site => array("\xE2\x84\xB9" . ' Link to register via the website:'),
    ref_tele => array("\xE2\x84\xB9" . 'Link to register via Telegram:'),


    faq => array("\xE2\x84\xB9" . ' FAQ', 'Frequently asked Questions
    
<b>Question: Who can become your investor?</b>
Answer: We accept funds only from adult citizens. Our unique high-tech system allows distributing any means in an effective way – the minimum deposit is only $10!
         
                        
<b>Question: How do I register?</b>
Answer: Just contact our Santa Bot on Telegram messenger, and make your first investment when it is comfortable for you!
     
                        
<b>Question: Will my data be secure?</b>
Answer: Telegram is the most secure Internet messenger in the world! Besides, we use additional encryption algorithms for our customers data.
  '),
    support => array("\xF0\x9F\x93\x9E" . ' Support',
        'If you have a question - ask our support team' . _NL_ .
		'https://santabot.net/support' . _NL_ .
		'Your Telegram ID: #uid#'
	),
    about => 'About bot',

);

$messages = array(
    unknownCmd => array(
        'I am very busy at the moment and can't speak! I can only help you with the investments.'
    ),
    done => array(
        'Done'
    ),
    error => array(
        'Error'
    ),
    errors => array(
        ref_wrong => 'Inviter not found',
        ref_not_empty => 'Inviter is already installed',

        sum_wrong => 'wrong ammount',
        format_wrong => 'wrong format',
        plan_wrong => 'plan not found',
        low_bal1 => 'not enough funds',
        no_funds => 'no funds',
        no_depo => 'you have no deposits',
        wallet_not_defined => 'please fill the wallet',
        wallet_not_empty => 'wallet alredy set',

        unknown_mehod => 'In development'
    ),
    'notify' => array(
        NewRef => 'Congratulations, you have a new partner. ID your new partner- #refid#',
        CASHIN => 'You have made deposit #sum# #cname# (batch: #batch#)',
        CALCIN => 'Your deposit profit #sum# #cname#',
        REF => 'Ref bonus from parnters investment #sum# #cname# (partner: #refid#)',
        CASHOUT => 'Was transfered  #sum# #cname# on your wallet#acc# (batch: #batch#)'
    )
);

$opers = array(
    'GIVE' => 'Deposit',
    'CALCIN' => 'Accrual'
);
?>