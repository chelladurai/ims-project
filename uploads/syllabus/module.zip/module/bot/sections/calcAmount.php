<?php

botSet('calc', $data['cid']);

$amounts = array(
	'USD' => array(
		array(10, 15, 25),
		array(50, 100, 250),
		array(500, 1000, 2000),
		array(3000, 5000, 10000)
	),
	'EUR' => array(
		array(10, 15, 25),
		array(50, 100, 250),
		array(500, 1000, 2000),
		array(3000, 5000, 10000)
	),
	'RUB' => array(
		array(600, 1000, 1500),
		array(2000, 5000, 10000),
		array(15000, 20000, 35000),
		array(50000, 75000, 100000)
	),
	'BTC' => array(
		array(0.02, 0.05, 0.1),
		array(0.2, 0.5, 1.0),
		array(1.5, 2.0, 3.0),
		array(5.0, 10.0, 20.0)
	)
);

$keys = array();
foreach ($amounts[$data['value']] as $r)
{
	$row = array();
	foreach ($r as $z)
		$row[botCurr($data['value']) . $z] = array(
			'section' => 'calcShow',
			'value' => $z,
			'cid' => $data['cid']
		);
	$keys[] = $row;
}
$keys[] = array(
	$lang['calcAmountInput'][0] => array(
		'section' => 'calcAmountInput',
		'cid' => $data['cid']
	)
);

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);

?>