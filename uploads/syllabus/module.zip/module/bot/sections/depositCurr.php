<?php

$keys = array(
	array(
		'USD' => array(
			'section' => 'depositPSys',
			'value' => 'USD'
		),
		'EUR' => array(
			'section' => 'depositPSys',
			'value' => 'EUR'
		),
		/*'RUB' => array(
			'section' => 'depositPSys',
			'value' => 'RUB'
		),*/
		'BTC' => array(
			'section' => 'depositPSys',
			'value' => 'BTC'
		)
	)
);

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);

?>