<?php



function botGetDepositLinkBTC($cid, $sum)
{
    require_once('lib/psys.php');

    global $db, $_cfg;
    $table = 'Opers';

    $out_link = moduleToLink('index');

    
    useLib('depo');
    $err = opDepoCreate(_uid(), $cid, $sum, 0, 0, false, 2);
    if ($err != 'passed')
        return($err);


    useLib('balance');

    $sid = md5(uniqid() . $cid . $sum);
    $err = opOperCreate(_uid(), 'CASHIN', $cid, $sum, array('SID' => $sid), '');
    if (is_string($err))
        return $err;
    global $_currs;

    $el = $db->fetch1Row($db->select("$table LEFT JOIN Users on uID=ouID LEFT JOIN Currs on cID=ocID", '*',
        "oSID=? and oOper=?", array($sid, 'CASHIN')));

    $checklink = moduleToLink('balance/addfunds') . "?sid=$sid";

    if (!$el)
        return 'error';

    stampArrayToStr($el, 'oCTS, oTS, oNTS');
    $el['oParams'] = strToArray($el['oParams']);
    $el['oParams2'] = strToArray($el['oParams2']);
    stampArrayToStr($el['oParams2'], 'date', 1);

    if ($el['oState'] <= 2)
    {
        opDecodeCurrParams($el, $p, $p_sci, $p_api);
        if (in_array($el['cCASHINMode'], array(2, 3)))
        {
            $res = array('pform',  prepareSCI(
                $el['cCID'], $p, $p_sci, $el['oSum'], $el['oParams2']['memo'], $el['oID'],
                fullURL("$checklink&check"),
                fullURL($out_link),
                valueIf(!$p_sci['hideurl'],
                    fullURL(moduleToLink('balance/status'), 0)
                ),
                opDecodeUserCurrParams($_currs[$el['cID']]),
                $_cfg['Bal_ForcePayer']
            ), $p, $p_sci,$el['oID']);


            return $res;
        }

    }

    return 0;
}



$cid = $session['depositPSys'];
$pid = $session['depositPlan'];
$sum = $data['value'];

if ($cid ==5) {
    $result = botGetDepositLinkBTC($cid, $sum, $pid);
    $l = strpos($result[1]['url'], 'payto=');
    $l = substr($result[1]['url'],$l+6);
}
else
$result = botGetDepositLink($cid, $sum, $pid);


if (!is_array($result))
	return botError($result);
global $_currs;
botLog("cid: $cid, sum: $sum");
botLog($ssum = botCurr($cid) . _z($sum, $cid) . ' ' . $_currs[$cid]['cName']);
botFillTemplate(
	$section,
	array(
		'sum' => $ssum
	)
);

if ($cid==5){
    botSay("{$lang[$section][2]} $ssum  BTC:");
    botSay($l);
}

return array(
	'text' => $lang[$section][1] . _NL_ . ($cid==5) ?"{$lang[$section][3]}" : reset($result)
);

?>