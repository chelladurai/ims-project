<?php

$keys = array(
	array(
		'USD' => array(
			'section' => 'calcAmount',
			'value' => 'USD',
			'cid' => 2
		),
		'EUR' => array(
			'section' => 'calcAmount',
			'value' => 'EUR',
			'cid' => 6
		),
		/*'RUB' => array(
			'section' => 'calcAmount',
			'value' => 'RUB',
			'cid' => 7
		),*/
		'BTC' => array(
			'section' => 'calcAmount',
			'value' => 'BTC',
			'cid' => 5
		)
	)
);

return array(
	'text' => $lang[$section][1],
	'keys' => $keys
);

?>