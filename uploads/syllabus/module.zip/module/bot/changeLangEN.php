<?php

botSet('lang', 'en');

require('module/bot/lang_en.php');
foreach ($lang as $s => &$l)
	if (!is_array($l))
		$l = array($l, $l);

return array('goto' => 'home');

?>