<?php

include_once('lib/inet.php');

class Bot
{

	public function getRequest()
	{
	}

	public function send($chat_id, $text, $keys = false)
	{
	}
	
	public function editKeys($chat_id, $message_id, $keys)
	{
	}
	
	public function sendPhoto($chat_id, $photo, $text = '')
	{
	}
}

?>