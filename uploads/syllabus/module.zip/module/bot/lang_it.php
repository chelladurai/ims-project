﻿<?php

$lang = array(
	start => "\xF0\x9F\x8F\x81" . ' Welcome on ! 
We give you 6% daily for 30 days on your investment' . _NL_ .'Please Choose your language' . _NL_ ,
    back => "\xE2\xAC\x85" . ' Back',
    home => array("\xF0\x9F\x8F\xA0".' Main menu', 'Welcome!' . _NL_ . 'Take a look in our FAQ area and get some tips for the beginning. '),
    nextPage => 'Show more',

    confirm => 'Confirm operation',
    confirmYes => array("\xE2\x9C\x85" . ' Confirm!', 'Operation  confirmed'),
    confirmNo => array("\xE2\x9D\x8C" . ' Cancel', 'Operation canceled'),

    zarabotok => array("\xF0\x9F\x92\xB0" . ' Balance', 'Your balance: ', 'No funds. Choose Add funds button.', 'Total Invested: ','Total Profit: ' ),

    depositBal => array("\xF0\x9F\x94\x83" . ' Reinvest'),
    depositBalPSys => array('Select Bitcoin Reinvest', 'Select Bitcoin Reinvest'),
	depositBalPlan => array('Selecting plan', 'Select plan'),
    depositBalAmount => array('What amount?', 'What amount to charge?'),
  //  depositBalAmountAll => array("\xE2\x86\xA9" . ' Reinvest all funds?'),
    depositBalAmountInput => array("\xF0\x9F\x92\xB2" . ' Set amount manual', 'Enter the amount '),
    depositBalAllAsk => array("\xF0\x9F\x98\x8E" . ' Reinvest all', 'Reinvest all available funds'),
    depositBalAll => 'Reinvest all',
    depositPSys => array("\xF0\x9F\x92\xB6" . ' Invest', 'Select payment system'),
    depositAmount => array('Select amount', 'How much you want to invest?'),
	depositPlan => array('Select plan', 'Select plan'),
    depositAmountInput => array("\xF0\x9F\x92\xB2" . ' Enter the amount manually', 'Enter the amount'),
    depositLink => array('Pay', 'To add funds #sum# follow to the link:' ,'pay to Bitcoin adress' ,'money will be on your deposit after 3 confirmations'),
    withdraw => array("\xF0\x9F\x92\xBC" . ' Withdraw', "\xF0\x9F\x93\xA4" . ' Withdrawal of funds to the wallet'),
    withdrawPSys => "\xF0\x9F\x92\xB3" . ' Select payment system',
    withdrawAll => 'Withdraw all',
    withdrawAmount => 'Select amount min. 0.002 BTC',
    withdrawAmountAll => "\xE2\x86\x97" . ' Withdraw all to the wallet ',
    withdrawAmountInput => array("\xF0\x9F\x92\xB2" . ' Enter the amount manually', 'Enter the amount '),
    deposits => array("\xF0\x9F\x92\xBC" . ' My deposits', ''),
    depositsList => 'Active deposits',
    depositsOpers => array('View another 10 operations', 'Deposit '),

    referral => array("\xF0\x9F\x91\xA5" . ' Referral system',
        'In your team #active# is #nonactive# users, wich invested $#zdepo#' . _NL_ .
        'You ref. bonus #zref#'
        . _NL_ .
        'In order to unlock the respective level, a minimum investment is required. In order to receive commissions on all four levels, an total invest of 1 BTC is required.', 

    ),
    ref1 => array("\x31\xE2\x83\xA3" . ' 1-st level',
        '<b>1 level</b>' . _NL_ .
        'Active / Inactive: #active# / #nonactive#' . _NL_ .
        'Invested funds: #zdepo#' . _NL_ .
        'The affiliate bonus: #zref#'
    ),
    ref2 => array("\x32\xE2\x83\xA3" . ' 2-nd level',
        '<b>2 level</b>' . _NL_ .
        'Active / Inactive: #active# / #nonactive#' . _NL_ .
        'Invested funds: #zdepo#' . _NL_ .
        'The affiliate bonus: #zref#'
    ),
    ref3 => array("\x33\xE2\x83\xA3" . ' 3-d level',
        '<b>3 level</b>' . _NL_ .
        'Active / Inactive: #active# / #nonactive#' . _NL_ .
        'Invested funds: #zdepo#' . _NL_ .
        'The affiliate bonus: #zref#'
    ),
    showRefLink => array("\xF0\x9F\x94\x97" . ' Your ref-link', 'Your ref-link'),
    changeUpRef => array("\xF0\x9F\x91\xA4" . ' Your inviter',
        'You have not specified inviter.' . _NL_ . 'Type the ID of the user who invited you (your inviter can choose Support button in the main menu to see his Telegram ID) ',
        'Your inviter: '
    ),

    settings => array("\xF0\x9F\x94\xA7" . ' Settings', 'Configuring your account settings'),
    changeWallet => array("\xF0\x9F\x94\x90" . ' Payment details', ' Details of your wallets'),
    changeWalletInput => 'Set Wallet ',
    changeLang => array("\xF0\x9F\x8C\x90" . ' Change language', 'Choose your language'),

    operations => array("\xF0\x9F\x93\x83" .  ' History', 'View a list of your transactions by type'),
    cashIn => array("\xF0\x9F\x93\xA5" . ' Deposits', 'Add funds operation:'),
    cashIn2 => array("\xF0\x9F\x93\xA5" . ' Add funds', 'Add funds operation:'),
    profit => array("\xF0\x9F\x93\xA5" . ' Profit', 'Profit operation:'),
    cashOut => array("\xF0\x9F\x93\xA4" . ' Withdraw', 'Withdrawal:'),
    refD => array("\xF0\x9F\x95\x90" . ' Ref.bonus', 'Affiliate bonus:'),

    ref_site => array("\xE2\x84\xB9" . ' Link to register via the website:'),
    ref_tele => array("\xE2\x84\xB9" . 'Link to register via Telegram:'),


    faq => array("\xE2\x84\xB9" . ' FAQ', '

 <b>What is ?</b>
We provide 6% daily  (1% every 4 hours for 30 days)

<b>How  works?</b>

 
 
  '),
    support => array("\xF0\x9F\x93\x9E" . ' Support',
        '<b>If you have a question - contact our support</b> ' . _NL_ .
                ' ' . _NL_ .
		'Please provide your Telegram ID: #uid#' . _NL_ .
		
                'Contact the support @BotSupport' . _NL_ .
                'News @BotNews'. _NL_ .'Community @BitStarCommunity'
                
                
	),
    about => 'About bot',

);

$messages = array(
    unknownCmd => array(
        'Unknown team'
    ),
    done => array(
        'DONE. Pending'
    ),
    error => array(
        'Error'
    ),
    errors => array(
        ref_wrong => 'Inviter not found',
        ref_not_empty => 'Inviter is already installed',

        sum_wrong => 'wrong ammount',
        format_wrong => 'wrong format',
        plan_wrong => 'plan not found',
        low_bal1 => 'not enough funds',
        no_funds => 'no funds',
        no_depo => 'you have no deposits',
        wallet_not_defined => 'please fill the wallet',
        wallet_not_empty => 'wallet already set',

        unknown_mehod => 'In development'
    ),
    'notify' => array(
        NewRef => 'Congratulations, you have a new partner. ID your new partner- #refid#',
        CASHIN => 'We received your Payment #sum#',
        CALCIN => 'Your deposit profit #sum# #cname#',
        REF => 'Ref bonus from parnters investment #sum# #cname# (partner: #refid#)',
        CASHOUT => 'Was transfered  #sum# #cname# on your wallet#acc# (batch: #batch#)'
    )
);

$opers = array(
    'GIVE' => 'Deposit',
    'CALCIN' => 'Accrual'
);
?>
