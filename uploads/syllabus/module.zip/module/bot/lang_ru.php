﻿<?php

$lang = array(
	start => "\xF0\x9F\x8F\x81" . ' Willkommen beim BitStarBot!
Wir geben dir täglich 6% für 30 Tage auf dein Investment' . _NL_ .'Bitte wähle deine Sprache' . _NL_ ,
	back => "\xF0\x9F\x94\x99" . ' zurück',
	home => array("\xF0\x9F\x94\x9D".' Menü', 'Willkommen!' . _NL_ . 'Im FAQ Bereich haben wir einige nützliche Tipps für dich zusammengefasst, die dir den Start etwas einfacher machen' . _NL_ 
	
	


	),
	
	nextPage => 'Показать еще',

	confirm => 'Подтверждение операции',
		confirmYes => array("\xE2\x9C\x85" . ' Confirm!', 'Operation  confirmed'),
		confirmNo => array("\xE2\x9D\x8C" . ' Cancel', 'Operation canceled'),

    zarabotok => array("\xF0\x9F\x92\xB0" . ' Guthaben', 'Dein Guthaben: ', 'No funds. Choose Add funds button.', 'Gesamte Investition:','Total Profit: ' ),
	
		depositBal => array("\xF0\x9F\x94\x83" . ' Reinvest'),
			depositBalPSys => array('Bitcoin Reinvest' , 'Bitcoin Reinvest'),
			depositBalPlan => array('Выберите план', 'На какой план ты хочешь сделать вклад?'),
			depositBalAmount => array('Какую сумму?', 'На какую сумму пополнить?'),
            //  depositBalAmountAll => array("\xE2\x86\xA9" . ' Reinvest all funds?'),
			depositBalAmountInput => array("\xF0\x9F\x92\xB2" . ' Set amount manual', 'Wie viel möchtest du Reinvestieren? zb. 0.02 '),
			depositBalAllAsk => array("\xF0\x9F\x98\x8E" . ' Reinvest komplett', 'Kompletten Betrag Reinvestieren'),
			depositBalAll => 'Kompletten Betrag Reinvestieren',
		depositPSys => array("\xF0\x9F\x92\xB5" . ' Investieren', 'Выбери платежную систему'),
			depositAmount => array('Wähle einen Betrag', 'Wie viel möchtest du investieren?'),
			depositPlan => array('Выбери план', 'На какой план ты хочешь сделать вклад?'),
			depositAmountInput => array("\xF0\x9F\x92\xB2" . ' Wähle einen anderen Betrag', 'Wie viel möchtest du investieren? Summe, zum Beispiel: 1.5'),
    	depositLink => array('Pay', 'To add funds #sum# follow to the link:' ,'pay to Bitcoin adress' ,'money will be on your deposit after 3 confirmations'),
		withdraw => array("\xF0\x9F\x92\xBC" . ' Auszahlen', "\xF0\x9F\x93\xA4" . ' Zahle dein Guthaben direkt auf deine Wallet. Auszahlungen dauern in der Regel bis zu einigen Stunden. Bitte beachte die Blockchain.'),
			withdrawPSys => "\xF0\x9F\x92\xB3" . ' Bitcoin Auszahlung. Bitte bestätigen den Button',
			
			withdrawAmount => 'Wähle deinen Betrag zb. 0.02',
			withdrawAmountAll => "\xE2\x86\x97" . ' Kompletten Betrag auszahlen ',
			withdrawAmountInput => array("\xF0\x9F\x92\xB2" . ' Wähle deinen Betrag', 'Wähle deinen Betrag'),
		deposits => array("\xF0\x9F\x92\xBC" . ' Meine Einzahlungen', ''),
    depositsList => array("\xe2\x9c\x94" . 'Aktive Einzahlungen',' Tage zum Ende', '  180% complete'),
			depositsOpers => array('weitere 10 Einzahlungen anzeigen', 'Einzahlungen '),

	referral => array("\xF0\x9F\x91\xA5" . ' Mein Team - Ref-Link ',
		'In deinem gesamtem Team sind: #active# Aktive Referrals mit einer gesamten Investition von: #zdepo#'  . _NL_ .
		'Dein Profit: #zref# ergibt sich aus den verschiedenen Prozente Stufen.'
	
		
		
		
		
	
		),
		
	
		

	


			ref1 => array("	\xF0\x9F\x8F\x86" . '8%',
        '<b>Level / 8%</b>' . _NL_ .
        'Active / Inactive: #active#' . _NL_ .
        'Investition deiner Referrals: #zdepo#' . _NL_ .
        'Dein Profit: $#zref#'
			),
			ref2 => array("\xF0\x9F\x8F\x86" . ' 4%',
				'<b>Level / 4%</b>' . _NL_ .
				'Aktive / Inaktive: #active#' . _NL_ .
				'Investition deiner Referrals: #zdepo#' . _NL_ .
				'Dein Profit: #zref#'
			),
			ref3 => array("\xF0\x9F\x8F\x86" . ' 3%',
				'<b>Level / 3%</b>' . _NL_ .
				'Aktive / Inaktive: #active#' . _NL_ .
				'Investition deiner Referrals: #zdepo#' . _NL_ .
				'Dein Profit: #zref#'
			),
		showRefLink => array("\xF0\x9F\x94\x97" . ' Dein Ref-Link', 'Dein Ref-Link'),
		changeUpRef => array("\xF0\x9F\x91\xA4" . ' Dein Team-Leader', 
			'Du hast keinen Team-Leader.' . _NL_ . 'Du kannst einen Team-Leader hinzufügen, indem du seine Telegram ID hinzufügst. Dein Team-Leader findet seine ID in den Einstellungen',
			'Dein Team-Leader: '
		
		),

	settings => array("\xF0\x9F\x94\xA7" . ' Einstellungen', 'Ändere deine Account-Einstellungen'),
		changeWallet => array("\xF0\x9F\x94\x90" . ' Deine Wallet Adresse', 'Hier kannst du deine Wallet Adresse ändern / hinzufügen. Bitte klicke den Button.'),
			changeWalletInput => 'Sende uns deine Wallet Adresse ',
		changeLang => array("\xF0\x9F\x8C\x8E" . ' Ändere die Sprache', 'Bitte wähle zwischen folgenden Sprachen' . _NL_ ),

	operations => array("\xF0\x9F\x93\x83" . ' History', 'Schau dir deine History an'),
		cashIn => array("\xF0\x9F\x93\xA5" . ' Einzahlungen', 'Einzahlungs History:'),
		cashOut => array("\xF0\x9F\x93\xA4" . ' Auszahlungen', 'Auszahlungs History:'),
		refD => array("\xF0\x9F\x95\x90" . ' Team-Bonus', 'Dein Team Profit:'),

	ref_site => array("\xE2\x84\xB9" . ' Ссылка для регистрации через сайт:'),
	ref_tele => array("\xE2\x84\xB9" . ' Dein Ref-Link:'),

	tickets => array('Tickets', 'Wie können wir dir helfen?', 'You', 'Support'),
	rateus => array("\xE2\xAD\x90 ".'Rate us', 'Bitte bewerte uns hier! 🔥'. _NL_ . 'https://storebot.me/bot/bitstarbot'),
	pass => array("\xF0\x9F\x9A\xA8 ".'Passwort', 'Füge dein Passwort ein:', 
		'Fertig! Du kannst dich jetzt mit deinem Passwort und deinem Username ', ' auf unserer Webseite https://BitStarBot.com einloggen'),

	faq => array("\xF0\x9F\x94\x96" . ' FAQ', ' 
	<b>Was ist BitStarBot?</b>
Wir sind ein Trading Team welches dir auf deine Investition 6% täglich gibt. (1% alle 4 Std für 30 Tage)

<b>Wie kann ich eine Investition machen?</b>
Du kannst jederzeit zu viel du möchtest investieren (mind. 0.02BTC) Benutze einfach den Investieren Button und folge den Anweisungen

<b>Wie kann ich mein Guthaben auszahlen?</b>
Mindestauszahlungsbetrag 0.02 BTC
Du erhälst alle 4 Stunden 1% (6% täglich) Für Auszahlungen, benutze bitte den Auszahlungs Button und folge den Anweisungen. Deine Auszahlung wird Instant bearbeitet und sofort auf deine Wallet überwiesen.

<b>Wo finde ich mein Ref-Team / Link?</b>
Über den Mein Team - Ref - Link Button findest du alle nötigen Information wie z.B. deine Provision, die aktiven sowie nicht aktiven Team Mitglieder.

<b>Wie kann ich meine Auszahlungs-Adresse ändern</b>
Du kannst deine Wallet Adresse über den Einstellungs Button jederzeit ändern.


	

                       '),

	support => array("\xE2\x9D\x97" . ' Hilfe',

		'<b>Solltest du Fragen oder Probleme haben, kontaktiere bitte unseren Support.</b>' . _NL_ .
		''. 
		'Deine Telegram ID: #uid#' . _NL_ .
		
		
                'News @BitStarBotNews' . _NL_ . 'Community DE @BitStarBotCommunity' ,
	"\xF0\x9F\x93\xA9 ".'Erstelle ein Ticket'),
	about => 'Über den Bot',
	
);

$messages = array(
	unknownCmd => array(
		'Fehler'
	),
	done => array(
		'Erfolgreich. Erfolgreich'
	),
    sended => array(
        'Ticket erfolgreich versendet. Wir melden uns in Kürze!'
    ),
	error => array(
		'Fehler'
	),
	errors => array(
		ref_wrong => 'Kein Team-Leader gefunden',
		ref_not_empty => 'Team-Leader wurde schon hinzugefügt',
        sum_min => 'Falscher Betrag. Min. 0.02 BTC',
		sum_wrong => 'Falscher Betrag',
		format_wrong => 'Falsches Format',
		plan_wrong => 'Reinvest erst ab 0.02 möglich',
		low_bal1 => 'Nicht genügend Guthaben',
		no_funds => 'Kein Guthaben',
		no_depo => 'Du hast keine Einzahlungen/Deposits',
		wallet_not_defined => 'Bitte füge deine Auszahlungsadresse / Wallet hinzu',
		wallet_not_empty => 'Auszahlungsadresse schon hinzugefügt',

		unknown_mehod => 'In Bearbeitung'
	),
	'notify' => array(
		NewRef => 'Gratulation, du hast einen neuen Partner. ID deines Partners - #refid#',
		CASHIN => 'Einzahlung erfolgreich. #sum# ',
		CALCIN => 'Dein Profit #sum# ',
		REF => 'Ref-Bonus #sum# (Partner: #refid#)',
		CASHOUT => 'Auszahlung erfolgreich. Bitte warte bis zum Transfer ( kann bis zu 10 min dauern )'
	)
);

$opers = array(
	'GIVE' => 'Вклад',
	'CALCIN' => 'Начисление'
);

?>
