﻿<?php

$lang = array_merge($lang, array(
	changeLangEN => "\xF0\x9F\x87\xBA\xF0\x9F\x87\xB8" . ' English',
	changeLangRU => "\xF0\x9F\x87\xA9\xF0\x9F\x87\xAA" . ' Deutsch'/*,
	changeLangES => "\xF0\x9F\x87\xAA\xF0\x9F\x87\xB8" . ' soon',
	changeLangDE => "\xF0\x9F\x87\xB7\xF0\x9F\x87\xBA" . ' soon',
	changeLangFR => "\xF0\x9F\x87\xAB\xF0\x9F\x87\xB7" . ' soon',
	changeLangIT => "\xF0\x9F\x87\xAE\xF0\x9F\x87\xB9" . ' soon',
	*/
));

// меню доступных языков
$langs = array(
	array( changeLangEN, changeLangRU )

);

?>