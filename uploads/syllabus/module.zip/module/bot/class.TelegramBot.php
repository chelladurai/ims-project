<?php

require('class.Bot.php');

class TelegramBot extends Bot
{

	private $url;
	
	public function __construct($apiKey)
	{
		$this->url = 'https://api.telegram.org/bot' . trim($apiKey) . '/';
	}

	public function getRequest()
	{
		$req = @json_decode(file_get_contents('php://input'), 1);
		if (!is_array($req))
			return array();
		if ($req['callback_query'])
		{
			$data = array(
				'callback_query_id' => $req['callback_query']['id']
			);
			botLog('-- CALLBACK --');
			$res = @json_decode(inet_request($this->url . 'answerCallbackQuery', $data), 1);
			if (!$res['ok'])
				botLog($res['description']);
			$data = @json_decode($d = trim($req['callback_query']['data']), 1);
			if (!is_array($data))
				botLog("CallBack data wrong: $d");
			if (!$data['section'])
				exit; // disabled
			return array(
				'user_id' => $req['callback_query']['from']['id'],
				'chat_id' => $req['callback_query']['message']['chat']['id'],
				'message_id' => $req['callback_query']['message']['message_id'],
				'section' => $data['section'],
				'data' => $data
			);
		}
		else
			return array(
				'user_id' => $req['message']['from']['id'],
				'chat_id' => $req['message']['chat']['id'],
				'message_id' => $req['message']['message_id'],
				'request' => trim($req['message']['text']),
				'data' => array()
			);
	}

	public function send($chat_id, $text, $keys = true)
	{
		if (!$text)
			return false;
		$data = array(
			'chat_id' => $chat_id,
			'text' => $text,
			'parse_mode' => 'HTML'
		);
		if (is_array($keys))
			$data['reply_markup'] = json_encode($keys);
		elseif ($keys == false)
			$data['reply_markup'] = json_encode(array('hide_keyboard' => true));
		botLog('-- SEND --');
		botLog($data);
		$res = @json_decode(inet_request($this->url . 'sendMessage', $data), 1);
		botLog('-- ANSWER --');
		if (!$res['ok'])
			botLog($res['description']);
	}

	public function editKeys($chat_id, $message_id, $keys)
	{
		$data = array(
			'chat_id' => $chat_id,
			'message_id' => $message_id,
			'reply_markup' => json_encode(array('inline_keyboard' => botParseInlineKeys($keys)))
		);
		botLog('-- SEND EDIT --');
		botLog($data);
		$res = @json_decode(inet_request($this->url . 'editMessageReplyMarkup', $data), 1);
		botLog('-- ANSWER EDIT --');
		if (!$res['ok'])
			botLog($res['description']);
	}
	
	public function sendPhoto($chat_id, $photo, $text = '')
	{
		if (class_exists('CurlFile', false))
			$photo = new CURLFile(realpath($photo));
		else
			$photo = "@" . $photo;
		$data = array(
			'chat_id' => $chat_id,
			'photo' => $photo,
			'caption' => $text
		);
		botLog('-- SEND PHOTO --');
		botLog($data);
		$res = @json_decode(inet_request($this->url . 'sendPhoto', $data), 1);
		botLog('-- ANSWER PHOTO --');
		if (!$res['ok'])
			botLog($res['description']);
	}
	
}

?>