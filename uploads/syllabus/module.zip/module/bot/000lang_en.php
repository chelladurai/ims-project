﻿<?php

$lang = array(
	start => "\xF0\x9F\x8F\x81" . ' Welcome on Bake Mining!
We give you 5% daily for 30 days on your investment, Infos You can find @BakeMining or in our communities @BakeMiningComDE @BakeMiningComEN' . _NL_ .'Please Choose your language' . _NL_ ,
	back => "\xF0\x9F\x94\xB8" . ' Back',
	home => array("\xF0\x9F\x94\xB8" . ' Main menu', 'Welcome!' . _NL_ . 'Take a look in our FAQ area and get some tips for the beginning- ' . _NL_ . '' . _NL_ . 'With us, you will buy with 0.02 BTC ~ 12 M/Hash ETH Mining, which corresponds to the current ETH course ~ 5%' . _NL_ . '' . _NL_ . 'Currently, we are working on Automatic Ethereum Deposit, you should directly deposit with ETH, please contact @BakeMiningSupport with your bot ID and the deposit amount ' . _NL_ 
	
	


	),
    nextPage => 'Show more',

    confirm => 'Confirm operation',
    confirmYes => array("\xE2\x9C\x85" . ' Confirm!', 'Operation  confirmed'),
    confirmNo => array("\xE2\x9D\x8C" . ' Cancel', 'Operation canceled'),

    zarabotok => array("\xF0\x9F\x8C\x90" . ' Balance', 'Your balance: ', 'No funds. Choose Add funds button.', 'Total Invested: ','Total Profit: ' ),

    depositBal => array("\xF0\x9F\x94\xB8" . ' Reinvest'),
    depositBalPSys => array('Select Bitcoin Reinvest', 'Select Bitcoin Reinvest'),
	depositBalPlan => array('Selecting plan', 'Select plan'),
    depositBalAmount => array('What amount?', 'What amount to charge?'),
  //  depositBalAmountAll => array("\xE2\x86\xA9" . ' Reinvest all funds?'),
    depositBalAmountInput => array("\xF0\x9F\x92\xB2" . ' Set amount manual', 'Enter the amount '),
    depositBalAllAsk => array("\xF0\x9F\x98\x8E" . ' Reinvest all', 'Reinvest all available funds'),
    depositBalAll => 'Reinvest all',
    depositPSys => array("\xF0\x9F\x94\xB9" . ' Invest', 'Select payment system'),
    depositAmount => array('Select amount', 'How much you want to invest?'),
	depositPlan => array('Select plan', 'Select plan'),
    depositAmountInput => array("\xF0\x9F\x92\xB2" . ' Enter the amount manually', 'Enter the amount'),
    depositLink => array('Pay', 'To add funds #sum# follow to the link:' ,'pay to Bitcoin adress' ,'money will be on your deposit after 3 confirmations'),
    withdraw => array("\xF0\x9F\x94\xB9" . ' Withdraw', "\xF0\x9F\x93\xA4" . ' Withdrawal of funds to the wallet'),
    withdrawPSys => "\xF0\x9F\x92\xB3" . ' Select payment system',
    withdrawAll => 'Withdraw all',
    withdrawAmount => 'Select amount min. 0.002 BTC',
    withdrawAmountAll => "\xE2\x86\x97" . ' Withdraw all to the wallet ',
    withdrawAmountInput => array("\xF0\x9F\x92\xB2" . ' Enter the amount manually', 'Enter the amount '),
    deposits => array("\xF0\x9F\x92\xBC" . ' My deposits', ''),
    depositsList => 'Active deposits',
    depositsOpers => array('View another 10 operations', 'Deposit '),

    referral => array("\xF0\x9F\x94\xB9" . ' Referral system',
        'In your team #active# is #nonactive# users, wich invested #zdepo# BTC' . _NL_ .
        'You ref. bonus #zref# BTC'
        . _NL_ .
        'All your team deposits will be displayed automatically', 

    ),
    ref1 => array("\x31\xE2\x83\xA3" . ' -st level',
        '<b>1 level 10%</b>' . _NL_ .
        'Active / Inactive: #active# / #nonactive#' . _NL_ .
        'Invested funds: #zdepo# BTC' . _NL_ .
        'The affiliate bonus: #zref# BTC'
    ),
    ref2 => array("\x32\xE2\x83\xA3" . ' -nd level',
        '<b>2 level 5%</b>' . _NL_ .
        'Active / Inactive: #active# / #nonactive#' . _NL_ .
        'Invested funds: #zdepo# BTC' . _NL_ .
        'The affiliate bonus: #zref# BTC'
    ),
    ref3 => array("\x33\xE2\x83\xA3" . ' -d level',
        '<b>3 level 2%</b>' . _NL_ .
        'Active / Inactive: #active# / #nonactive#' . _NL_ .
        'Invested funds: #zdepo# BTC' . _NL_ .
        'The affiliate bonus: #zref# BTC'
    ),
    showRefLink => array("\xF0\x9F\x94\xB9" . ' Your ref-link', 'Your ref-link'),
    changeUpRef => array("\xF0\x9F\x94\xB9" . ' Ethereum',
        'Coming soon'
    ),

    settings => array("\xF0\x9F\x94\xB9" . ' Settings', 'Configuring your account settings'),
    changeWallet => array("\xF0\x9F\x94\xB9" . ' BTC Wallet', ' Details of your wallets'),
    changeWalletInput => 'Set Wallet ',
    changeLang => array("\xF0\x9F\x8C\x90" . ' Change language', 'Choose your language'),

    operations => array("\xF0\x9F\x94\xB8" . ' History', 'View a list of your transactions by type'),
    cashIn => array("\xF0\x9F\x94\xB9" . ' Deposits', 'Add funds operation:'),
    cashIn2 => array("\xF0\x9F\x93\xA5" . ' Add funds', 'Add funds operation:'),
    profit => array("\xF0\x9F\x93\xA5" . ' Profit', 'Profit operation:'),
    cashOut => array("\xF0\x9F\x94\xB9" . ' Withdraw', 'Withdrawal:'),
    refD => array("\xF0\x9F\x8C\x90" . ' Ref.bonus', 'Affiliate bonus:'),

    ref_site => array("\xE2\x84\xB9" . ' Link to register via the website:'),
    ref_tele => array("\xE2\x84\xB9" . 'Link to register via Telegram:'),


    faq => array("\xF0\x9F\x94\xB8" . ' FAQ', '

<B> What is Bake Mining? </ B>
Please read them in Telegram under @BakeMining

<B> Important Data </ ​​b>
5% Daily for 30 days
min. Invest 0.02 BTC
min. Reinvest 0.02 BTC
min. Payout 0.05 BTC
Payout amount? 1x every 24 hours
Team Levels: 1 Level 10%, 2 Level 5%, 3 Level 2%

<B> How can I make an investment? </ B>
You can invest too much at any time (at least 0.02BTC). Just use the Invest button and follow the instructions

<B> How can I pay out my credit balance? </ B>
You will receive 5% Daily. For withdrawals, please use the payout button and follow the instructions. Your payout is instantly processed and immediately transferred to your wallet. Payouts are possible once a 24h from an amount of 0.05BTC.

<B> Where can I find my Ref-Team / Link? </ B>
My Team - Ref - Link button provides you with all the necessary information, such as. Your commission, the active as well as inactive team members.

<B> How do I change my payout address? </ B>
You can change your Wallet address at any time using the Settings button.

 
 
  '),
    support => array("\xF0\x9F\x94\xB8" . ' Support',
        '<b>If you have a question - contact our support</b> ' . _NL_ .
                ' ' . _NL_ .
		'Please provide your Telegram ID: #uid#' . _NL_ .
		
                'Contact the support @BakeMiningComEN and @BakeMiningComDE' . _NL_ .
                'News @BakeMining'. _NL_ .
                
                
	),
    about => 'About bot',

);

$messages = array(
    unknownCmd => array(
        'Unknown team'
    ),
    done => array(
        'DONE. Pending'
    ),
    error => array(
        'Error'
    ),
    errors => array(
        ref_wrong => 'Inviter not found',
        ref_not_empty => 'Inviter is already installed',

        sum_wrong => 'wrong ammount',
        format_wrong => 'wrong format',
        plan_wrong => 'plan not found',
        low_bal1 => 'not enough funds',
        no_funds => 'no funds',
        no_depo => 'you have no deposits',
        wallet_not_defined => 'please fill the wallet',
        wallet_not_empty => 'wallet already set',

        unknown_mehod => 'In development'
    ),
    'notify' => array(
        NewRef => 'Congratulations, you have a new partner. ID your new partner- #refid#',
        CASHIN => 'We received your Payment #sum#',
        CALCIN => 'Your deposit profit #sum# #cname#',
        REF => 'Ref bonus from parnters investment #sum# #cname# (partner: #refid#)',
        CASHOUT => 'Was transfered  #sum# #cname# on your wallet#acc# (batch: #batch#)'
    )
);

$opers = array(
    'GIVE' => 'Deposit',
    'CALCIN' => 'Accrual'
);
?>
