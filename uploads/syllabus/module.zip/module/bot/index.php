<?php

// telegram.me/your_bot?start=XXXX

require('class.TelegramBot.php');
$bot = new TelegramBot('377756509:AAHWF-n030A1qJ5-22CNZ2eBhhxBesMSRQw');

//botLog('-- REQUEST --');
$req = $bot->getRequest();
//botLog($req);

$user_id = $req['user_id'];
if (!$user_id)
	die('Bot handler');

$chat_id = $req['chat_id'];
$message_id = $req['message_id'];

$section = $req['section']; // callback
$data = $req['data'];

$request = $req['request']; // запрос

$session = botLoad($user_id); // загрузить сессию юзера
$session_need_save = false;	// сессия не изменялась

if (!$chat_id)
	$chat_id = $session['chat_id'];
elseif ($session['chat_id'] != $chat_id)
	botSet('chat_id', $chat_id);

if (!$session['lang'])
	botSet('lang', 'en');

require("lang_$session[lang].php"); // языковый файл
require('langs.php'); // доступные языки
require('sections.php'); // описание секций

if (!$session['section'])
	botSet('section', 'start'); // первая (после старта) секция

foreach ($lang as $s => &$l) // "расширяем" описание
{
	if (!is_array($l))
		$l = array($l, $l);
	if (!$section and (trim($l[0]) == $request)) // если не callback
		$section = $s; // секция-обработчик текущего запроса
}
if (trim(substr($request, 0, 7)) == '/start')
	$section = 'start';

// ********** HS **********
global $_GS, $_cfg, $db, $_user, $_currs;
session_id(md5($_GS['domain']));
$_smode = 2;
require_once('module/auth.php');
$_GS['lang'] = $params['lang'];
$_GS['lang_dir'] = getLangDir();
if (!$session['uid'])
	botSet('uid', $db->fetch1($db->select('AddInfo', 'auID', 'aTelegramID=?', array($user_id))));
$_SESSION['_uid'] = $session['uid'];
$_user = $db->fetch1Row($db->select('Users LEFT JOIN AddInfo ON auID=uID', '*', 'uID=?d', array(_uid())));
$_currs = $db->fetchIDRows($db->select('Currs LEFT JOIN Wallets ON wcID=cID and wuID=?d',
	'*', 'cDisabled=0', array(_uid()), 'cID'), false, 'cID');
// ********** HS **********

if (isset($lang[$section]) or isset($sections[$section])) // это известная нам секция
	botExecute($section);
elseif (!botExecute($session['section'], true)) // это данные, вызываем обработчик текущей секции
	$bot->send( // вывод ошибки
		$chat_id,
		$messages['unknownCmd'][array_rand($messages['unknownCmd'])]
	);
	
if ($session_need_save) // сохранить сессию при необходимости
	botSave($user_id, $session);

?>