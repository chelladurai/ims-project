﻿<?php

$lang = array(
	start => "\xF0\x9F\x8F\x81" . ' Willkommen beim Bake Mining Bot!
Wir geben dir täglich 5% für 30 Tage auf dein Investment, Infos Findest du unter @BakeMining oder in unseren Communities @BakeMiningComDE @BakeMiningComEN' . _NL_ .'Bitte wähle deine Sprache' . _NL_ ,
	back =>  "\xF0\x9F\x94\xB8" . ' zurück',
	home => array("\xF0\x9F\x94\xB8" . ' Menü', 'Willkommen!' . _NL_ . 'Im FAQ Bereich haben wir einige nützliche Tipps für dich zusammengefasst, die dir den Start etwas einfacher machen- ' . _NL_ . '' . _NL_ . 'Bei uns erwirbst du für 0.02 BTC 12 M/Hash ETH Mining, das entspricht beim Aktuellen ETH Kurs ~5%' . _NL_ . '' . _NL_ . 'Derzeit Arbeiten wir an der Automatischen Ethereum Einzahlung, solltest du direkt mit ETH einzahlen wollen, wende dich bitte an @BakeMiningSupport mit deiner Bot-ID und den Einzahlungsbetrag ' . _NL_ 
	
	


	),
	
	nextPage => 'mehr Anzeigen',

	confirm => 'Bearbeitungs Bestätigung',
		confirmYes => array("\xE2\x9C\x85" . ' Bestätige!', 'Das Auswählen wird Bestätigt'),
		confirmNo => array("\xE2\x9D\x8C" . ' Stonieren', 'Vorgang Abgebrochen'),

    zarabotok => array("\xF0\x9F\x8C\x90" . ' Guthaben', 'Dein Guthaben: ', 'Kein Guthaben. Benutze Guthaben Aufladen Button.', 'Gesamte Investition:','Total Profit: ' ),
	
		depositBal => array("\xF0\x9F\x94\xB8" . ' Reinvest'),
			depositBalPSys => array('Bitcoin Reinvest' , 'Bitcoin Reinvest'),
			depositBalPlan => array('Wählen Sie', 'Der Plan auf dem Sie einzahlen möchten?'),
			depositBalAmount => array('Wie viel?', 'Wie viel möchten Sie Aufladen?'),
            //  depositBalAmountAll => array("\xE2\x86\xA9" . ' Reinvest kompletten Betrag?'),
			depositBalAmountInput => array("\xF0\x9F\x92\xB2" . ' Set amount manual', 'Wie viel möchtest du Reinvestieren? zb. 0.02 '),
			depositBalAllAsk => array("\xF0\x9F\x98\x8E" . ' Reinvest komplett', 'Kompletten Betrag Reinvestieren'),
			depositBalAll => 'Kompletten Betrag Reinvestieren',
		depositPSys => array("\xF0\x9F\x94\xB9" . ' Investieren', 'Выбери платежную систему'),
			depositAmount => array('Wähle einen Betrag', 'Wie viel möchtest du investieren?'),
			depositPlan => array('Выбери план', 'На какой план ты хочешь сделать вклад?'),
			depositAmountInput => array("\xF0\x9F\x92\xB2" . ' Wähle einen anderen Betrag', 'Wie viel möchtest du investieren? Summe, zum Beispiel: 1.5'),
    	depositLink => array('Pay', 'To add funds #sum# follow to the link:' ,'Zahle an folgende Bitcoin adress' ,'Bitcoins werden nach 3 Bestätigungen Gutgeschrieben'),
		withdraw => array("\xF0\x9F\x94\xB9" . ' Auszahlen', "\xF0\x9F\x93\xA4" . ' Zahle dein Guthaben direkt auf deine Wallet'),
			withdrawPSys => ' Bitcoin Auszahlung',
			withdrawAll => 'Alles Auszahlen',
			withdrawAmount => 'Wähle deinen Betrag zb. 0.002',
			withdrawAmountAll => "\xE2\x86\x97" . ' Kompletten Betrag auszahlen ',
			withdrawAmountInput => array("\xF0\x9F\x92\xB2" . ' Wähle deinen Betrag', 'Wähle deinen Betrag'),
		deposits => array("\xF0\x9F\x92\xBC" . ' Meine Einzahlungen', ''),
    depositsList => array("\xe2\x9c\x94" . 'Aktive Einzahlungen',' Tage bis zum Ende', '  150% complete'),
			depositsOpers => array('weitere 10 Einzahlungen anzeigen', 'Einzahlungen '),

	referral => array("\xF0\x9F\x94\xB9" . ' Mein Team ',
		'In deinem Team sind: #active# Aktive Referrals und: #nonactive# nicht Aktive Referrals, mit einer gesamte Investition von: #zdepo# BTC' . _NL_ .
		'Dein Profit: #zref# BTC' . _NL_ . 
	
		'Alle Einzahlungen deines Teams werden dir hier Automatisch angezeigt' , 
		
	
		),
		
	
		

	


			ref1 => array("\x31\xE2\x83\xA3" . ' level ',
				'<b>1 Level 10%</b>' . _NL_ .
				'Aktive / Inaktive: #active# / #nonactive#' . _NL_ .
				'Investition deiner Referrals: #zdepo# BTC' . _NL_ .
				'Dein Profit: #zref# BTC'
			),
			ref2 => array("\x32\xE2\x83\xA3" . ' level ',
				'<b>2 Level 5%</b>' . _NL_ .
				'Aktive / Inaktive: #active# / #nonactive#' . _NL_ .
				'Investition deiner Referrals: #zdepo# BTC' . _NL_ .
				'Dein Profit: #zref# BTC'
			),
			ref3 => array("\x33\xE2\x83\xA3" . ' Level ',
				'<b>3 Level 2%</b>' . _NL_ .
				'Aktive / Inaktive: #active# / #nonactive#' . _NL_ .
				'Investition deiner Referrals: #zdepo# BTC' . _NL_ .
				'Dein Profit: #zref# BTC'
			),
		showRefLink => array("\xF0\x9F\x94\xB9" . ' Ref-Link', 'Ref-Link'),
		changeUpRef => array("\xF0\x9F\x94\xB9" . ' Ethereum', 
			'Coming soon.' . _NL_ . 'Coming soon',
			'für Einzahlungen in ETH wende dich bitte an @BakeMiningSupport, wir Arbeiten derzeit an der AUtomatischen Einzahlung'
		
		),

	settings => array("\xF0\x9F\x94\xB9" . ' Einstellungen', 'Ändere deine Account-Einstellungen'),
		changeWallet => array("\xF0\x9F\x94\xB9" . ' BTC Wallet', 'Hier kannst du deine Wallet Adresse ändern / hinzufügen. Bitte klicke den Button.'),
			changeWalletInput => 'Sende uns deine Wallet Adresse ',
		changeLang => array("\xF0\x9F\x8C\x90" . ' Ändere die Sprache', 'Bitte wähle zwischen folgenden Sprachen' . _NL_ ),

	operations => array("\xF0\x9F\x94\xB8" . ' History', 'Schau dir deine History an'),
		cashIn => array("\xF0\x9F\x94\xB9" . ' Einzahlungen', 'Einzahlungs History:'),
		cashOut => array("\xF0\x9F\x94\xB9" . ' Auszahlungen', 'Auszahlungs History:'),
		refD => array("\xF0\x9F\x8C\x90" . ' Team-Bonus', 'Dein Team Profit:'),

	ref_site => array("\xE2\x84\xB9" . ' Link über die Website:'),
	ref_tele => array("\xE2\x84\xB9" . ' Dein Ref-Link:'),

	faq => array("\xF0\x9F\x94\xB8" . ' FAQ', ' 
	<b>Was ist Bake Mining?</b>
Das Lesen sie Bitte in Telegram unter @BakeMining nach

<b>Wichtige Daten</b>
5% Täglich für 30 Tage
min. Invest 0.02 BTC
min. Reinvest 0.02 BTC
min. Auszahlung 0.05 BTC
Auszahlungs Menge? 1x alle 24 Stunden
Team Ebenen: 1 Level 10%, 2 Level 5%, 3 Level 2%

<b>Wie kann ich eine Investition machen?</b>
Du kannst jederzeit zu viel du möchtest investieren (mind. 0.02BTC) Benutze einfach den Investieren Button und folge den Anweisungen

<b>Wie kann ich mein Guthaben auszahlen?</b>
Du erhälst 5% Täglich. Für Auszahlungen, benutze bitte den Auszahlungs Button und folge den Anweisungen. Deine Auszahlung wird Instant bearbeitet und sofort auf deine Wallet überwiesen. Auszahlungen sind 1x alle 24h ab einem Betrag von 0.05BTC möglich.

<b>Wo finde ich mein Ref-Team / Link?</b>
Über den Mein Team - Ref - Link Button findest du alle nötigen Information wie z.B. deine Provision, die aktiven sowie nicht aktiven Team Mitglieder.

<b>Wie kann ich meine Auszahlungs-Adresse ändern</b>
Du kannst deine Wallet Adresse über den Einstellungs Button jederzeit ändern.


	

                       '),

	support => array("\xF0\x9F\x94\xB8" . ' Support',

		'<b>Solltest du Fragen oder Probleme haben, kontaktiere bitte unseren Support.</b>' . _NL_ .
		'' . _NL_ .
		'Bitte teile dem Support deine Telegram ID mit: #uid#' . _NL_ .
                '<b>Du erreichst den Support hier:</b> @BakeMiningComDE und @BakeMiningComEN' . _NL_ .
                'News @BakeMining'
	),
	about => 'Über den Bot',
	
);

$messages = array(
	unknownCmd => array(
		'Unknown team'
	),
	done => array(
		'Erfolgreich. Erfolgreich'
	),
	error => array(
		'Fehler'
	),
	errors => array(
		ref_wrong => 'Kein Team-Leader gefunden',
		ref_not_empty => 'Team-Leader wurde schon hinzugefügt',

		sum_wrong => 'Falscher Betrag',
		format_wrong => 'Falsches Format',
		plan_wrong => 'Plan nicht gefunden',
		low_bal1 => 'Nicht genügend Guthaben',
		no_funds => 'Kein Guthaben',
		no_depo => 'Du hast keine Einzahlungen/Deposits',
		wallet_not_defined => 'Bitte füge deine Auszahlungsadresse / Wallet hinzu',
		wallet_not_empty => 'Auszahlungsadresse schon hinzugefügt',

		unknown_mehod => 'In Bearbeitung'
	),
	'notify' => array(
		NewRef => 'Gratulation, du hast einen neuen Partner. ID deines Partners - #refid#',
		CASHIN => 'Einzahlung erfolgreich. #sum# ',
		CALCIN => 'Dein Profit #sum# ',
		REF => 'Ref-Bonus #sum# (Partner: #refid#)',
		CASHOUT => 'Auszahlung erfolgreich. Bitte warte bis zum Transfer'
	)
);

$opers = array(
	'GIVE' => 'Вклад',
	'CALCIN' => 'Начисление'
);

?>
