<?php

$sections = array(

// стандартные
    start => $langs,
    back => 1,
    home => array(
        array( zarabotok ),
        array( depositPSys, withdraw ),
        array(  depositBal,operations ),
        array( referral,settings ),

        array( faq, support )
    ),
    faq => 1,
    support => 1,

    confirm => array(
        array( confirmYes, confirmNo )
    ),
    confirmYes => 1,
    confirmNo => 1,



    depositAmountInput => array(),

    referral => array(
        array( zarabotok ),
        array( changeUpRef,showRefLink ),

        array( ref1 , ref2, ref3 )
    ),

    operations => array(
        array( cashIn, cashOut ),
        array( refD )
    ),

    settings => array(
        array( zarabotok ),
        array( changeWallet,changeUpRef ),
        array( changeLang ),
    ),
	withdrawAmountInput => array(),
    changeLang => $langs,
	changeUpRef => array(),
    changeWallet => 1,
    changeWalletInput => array(),
// о боте
    about => 1

);

// добавим обработчики доступных языков
foreach ($langs as $r)
    foreach ($r as $l)
        $sections[$l] = 1;

?>