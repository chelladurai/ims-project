﻿<?php

$lang = array(
	start => "\xF0\x9F\x8F\x81" . ' Bienvenido al Hornear Minería Bot!

Le damos a diario 5% durante 30 días de su inversión, información que se encuentra bajo @BakeMining o en nuestras comunidades @BakeMiningComDE @BakeMiningComEN' . _NL_ .'Seleccione su idioma' . _NL_ ,
	back => "\xF0\x9F\x94\x99" . ' espalda',
	home => array("\xF0\x9F\x87\xAA\xF0\x9F\x87\xB8".' menú', 'Bienvenida!' . _NL_ . 'En la sección de preguntas frecuentes que hemos colocado algunos consejos útiles para usted combinada que hacer que empezar un poco más fácil' . _NL_ 
	
	


	),
	
	nextPage => 'más anuncios',

	confirm => 'confirmación de la edición',
		confirmYes => array("\xE2\x9C\x85" . ' presentar!', 'La selección se confirma'),
		confirmNo => array("\xE2\x9D\x8C" . ' cancelar', 'proceso Cancelado'),

    zarabotok => array("\xF0\x9F\x92\xB0" . ' crédito', 'su saldo: ', 'Sin crédito. Utilice el botón de carga de crédito.', 'la inversión total: ','El beneficio total: ' ),
	
		depositBal => array("\xF0\x9F\x94\x83" . ' reinvertir'),
			depositBalPSys => array('Bitcoin Reinvertir' , 'Bitcoin Reinvertir'),
			depositBalPlan => array('Select' 'que desea depositar en el plan al respecto?'),
			depositBalAmount => array('cuánto?', 'Cuánto quiere cobrar?'),
            //  depositBalAmountAll => array("\xE2\x86\xA9" . ' Volver a invertir importe total?'),
			depositBalAmountInput => array("\xF0\x9F\x92\xB2" . ' Set amount manual', 'La cantidad que desea volver a invertir?'),
			depositBalAllAsk => array("\xF0\x9F\x98\x8E" . ' volver a invertir por completo', 'El monto total Reinvertir'),
			depositBalAll => 'El monto total Reinvertir',
		depositPSys => array("\xF0\x9F\x92\xB5" . ' invertir', 'Выбери платежную систему'),
			depositAmount => array('Seleccione una cantidad', 'La cantidad que desea invertir?'),
			depositPlan => array('Выбери план', 'На какой план ты хочешь сделать вклад?'),
			depositAmountInput => array("\xF0\x9F\x92\xB2" . ' Elija una cantidad diferente', 'La cantidad que desea invertir? Total, por ejemplo: 1.5'),
    	depositLink => array('Pay', 'To add funds #sum# follow to the link:' ,'Pagar en la siguiente dirección Bitcoin' ,'Bitcoins son después de tres confirmaciones Acreditado'),
		withdraw => array("\xF0\x9F\x92\xBC" . ' saldar', "\xF0\x9F\x93\xA4" . ' Pagar el saldo de su cartera'),
			withdrawPSys => "\xF0\x9F\x92\xB3" . ' pago Bitcoin',
			
			withdrawAmount => 'Seleccione la cantidad de su',
			withdrawAmountAll => "\xE2\x86\x97" . ' pagar la cantidad completa ',
			withdrawAmountInput => array("\xF0\x9F\x92\xB2" . ' Seleccione la cantidad de su', 'Seleccione la cantidad de su'),
		deposits => array("\xF0\x9F\x92\xBC" . ' Mis recibos', ''),
    depositsList => array("\xe2\x9c\x94" . 'depósitos activos',' Días restantes', '  150% completar'),
			depositsOpers => array('Ver otros 10 procede', 'ganancias '),

	referral => array("\xF0\x9F\x91\xA5" . ' mi equipo',
		'en su equipo: #active# Las referencias activas y: #nonactive# referencias no activos, con una inversión total de: #zdepo# BTC' . _NL_ .
		'su beneficio: #zref# BTC' 

		'Todos los depósitos de su equipo va a aparecer aquí automática', 
		
	
		),
		
	
		

	


			ref1 => array("\x31\xE2\x83\xA3" . ' nivel',
				'<b>1 nivel 10%</b>' . _NL_ .
				'Aktive / Inaktive: #active# / #nonactive#' . _NL_ .
				'Investition deiner Referrals: #zdepo# BTC' . _NL_ .
				'Dein Profit: #zref# BTC'
			),
			ref2 => array("\x32\xE2\x83\xA3" . ' nivel',
				'<b>2 nivel 5%</b>' . _NL_ .
				'Aktive / Inaktive: #active# / #nonactive#' . _NL_ .
				'Investition deiner Referrals: #zdepo# BTC' . _NL_ .
				'Dein Profit: #zref# BTC'
			),
			ref3 => array("\x33\xE2\x83\xA3" . ' nivel',
				'<b>3 nivel 2%</b>' . _NL_ .
				'Aktive / Inaktive: #active# / #nonactive#' . _NL_ .
				'Investition deiner Referrals: #zdepo# BTC' . _NL_ .
				'Dein Profit: #zref# BTC'
			),
		showRefLink => array("\xF0\x9F\x94\x97" . ' Su Ref-Link', 'Su Ref-Link'),
		changeUpRef => array("\xF0\x9F\x91\xA4" . ' Coming soon', 
			'Coming soon' . _NL_ . 'Coming soon',
			'Coming soon '
		
		),

	settings => array("\xF0\x9F\x94\xA7" . ' ajustes', 'Cambiar la configuración de cuenta'),
		changeWallet => array("\xF0\x9F\x94\x90" . ' Su dirección de Bitcoin', 'Editar su cartera cambio de dirección o añadir. Por favor, haga clic en el botón.'),
			changeWalletInput => 'Envíenos su dirección Monedero ',
		changeLang => array("\xF0\x9F\x8C\x8E" . ' Cambiar el idioma', 'Por favor seleccione de los siguientes idiomas' . _NL_ ),

	operations => array("\xF0\x9F\x93\x83" . ' Historia', 'Mire a su historia de'),
		cashIn => array("\xF0\x9F\x93\xA5" . ' ganancias', 'Historia de depósitos:'),
		cashIn2 => array("\xF0\x9F\x93\xA5" . ' ganancias', 'Historia de depósitos:'),
    profit => array("\xF0\x9F\x93\xA5" . ' Lucro', 'Operación de beneficio:'),
		cashOut => array("\xF0\x9F\x93\xA4" . ' pagos', 'Historia de pago:'),
		refD => array("\xF0\x9F\x95\x90" . ' Bono de equipo', 'Su equipo de Ganancias:'),

	ref_site => array("\xE2\x84\xB9" . ' Ссылка для регистрации через сайт:'),
	ref_tele => array("\xE2\x84\xB9" . ' Su Ref-Link:'),

	faq => array("\xE2\x9D\x97" . ' Preguntas más frecuentes', ' 
	<B> ¿Cuál es Hornear Minería? </ B>
Al leerlo en favor del telegrama bajo @BakeMining por

<B> Los datos importantes </b>
5% al ​​día durante 30 días
minuto Invertir 00:02 BTC
minuto Reinvertir 00:02 BTC
minuto Pago 0:05 BTC
cantidad a pagar? 1x cada 24 horas
niveles del equipo: Nivel 1 10% 2 Nivel 5%, 3 Nivel 2%

<B> ¿Cómo puedo hacer una inversión? </B>
Puede siempre demasiado usted desee invertir (min 0.02BTC.) Sólo tiene que utilizar el botón Invest y siga las instrucciones

<B> ¿Cómo puedo pagar mi crédito? </B>
Usted recibirá un 5% todos los días. Para retiros, utilice el botón de pago y siga las instrucciones. Su pago se procesa al instante y de inmediato trasladado a su cartera. Los pagos se 1x cada 24 horas a partir de una cantidad de 0.05BTC posible.

<B> ¿Dónde puedo encontrar mi equipo Ref / Link? </B>
Sobre el equipo de Mi - Ref - Botón de enlace se puede encontrar toda la información necesaria, como su comisión, los miembros activos del equipo y no activos.

<B> ¿Cómo puedo cambiar mi dirección de pagos </b>
Se puede cambiar en cualquier dirección de tiempo en el botón Configuración de su cartera.

	

                       '),

	support => array("\xE2\x98\x8E" . ' Apoyo',

		'Si tiene alguna pregunta o problema, por favor, póngase en contacto con nuestro apoyo.' . _NL_ .
		'' . _NL_ .
		'Por favor, dejar que el apoyo que su telegrama ID: #uid#' . _NL_ .
                '<b>Usted puede alcanzar el apoyo aquí:</b> @BakeMiningComDE y @BakeMiningComEN' . _NL_ .
                'News @BakeMining'
	),
	about => 'Sobre el Bot',
	
);

$messages = array(
	unknownCmd => array(
		'Equipo desconocido'
	),
	done => array(
		'Exitosa. exitoso'
	),
	error => array(
		'error'
	),
	errors => array(
		ref_wrong => 'Coming soon',
		ref_not_empty => 'Coming soon',

		sum_wrong => 'cantidad incorrecta',
		format_wrong => 'un formato incorrecto',
		plan_wrong => 'Plan nicht gefunden',
		low_bal1 => 'No es suficiente crédito',
		no_funds => 'sin crédito',
		no_depo => 'No tiene depósitos',
		wallet_not_defined => 'Por favor, añada su dirección de pago de Bitcoin',
		wallet_not_empty => 'dirección de pago ya añadió',

		unknown_mehod => 'en Progreso'
	),
	'notify' => array(
		NewRef => 'Felicitaciones, usted tiene una nueva pareja. Identificación su pareja - #refid#',
		CASHIN => 'depósito con éxito. #sum# ',
		CALCIN => 'su beneficio #sum# ',
		REF => 'Ref-Bonus #sum# (Partner: #refid#)',
		CASHOUT => 'Pago éxito. Por favor, espere hasta que la transferencia'
	)
);

$opers = array(
	'GIVE' => 'Вклад',
	'CALCIN' => 'Начисление'
);

?>
