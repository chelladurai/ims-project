<?php

$module = 'FAQ';
require_once('module/admin/setup.php');

showPage();

?>