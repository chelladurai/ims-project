<?php

$module = 'Review';
require_once('module/admin/setup.php');

showPage();

?>