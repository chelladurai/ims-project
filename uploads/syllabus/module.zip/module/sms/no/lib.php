<?php

function smsSend($q)
{
	return array(0, 'Select provider', 0, 0);
}

function smsCheck($ids) // array
{
	return array();
}
	
?>