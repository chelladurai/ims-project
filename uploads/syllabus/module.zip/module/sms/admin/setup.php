<?php

$module = 'SMS';
require_once('module/admin/setup.php');

showPage();

?>