<?php

$module = 'News';
require_once('module/admin/setup.php');

showPage();

?>