<?php

$module = 'UI';
require_once('module/admin/setup.php');

showPage();

?>