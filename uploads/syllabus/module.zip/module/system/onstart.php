<?php

$_GS['mail_host'] = $_cfg['Mail_Host'];
$_GS['mail_port'] = $_cfg['Mail_Port'];
$_GS['mail_secure'] = $_cfg['Mail_Secure'];
$_GS['mail_username'] = $_cfg['Mail_Username'];
$_GS['mail_password'] = $_cfg['Mail_Password'];

?>