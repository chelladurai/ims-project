<?php

$_auth = 0;
require_once('module/auth.php');

if ($_POST and isset($_GET['resend']))
{
	require_once('lib/inet.php');
	inet_request(fullURL(moduleToLink('balance/status'), false), $_POST);
}

require_once('lib/psys.php');



$table = 'Opers';
$out_link = moduleToLink('index');
//xStop("xcccccccccccccvxcv" );
if ($sid = _GET('sid'))
	$el = $db->fetch1Row($db->select("$table LEFT JOIN Users on uID=ouID LEFT JOIN Currs on cID=ocID", '*', 
		"oSID=? and oOper=?", array($sid, 'CASHIN')));
if (!$el)
	goToURL($out_link);
$checklink = moduleToLink('balance/addfunds') . "?sid=$sid";




if (isset($_GET['check']))
	if ($el['oState'] >= 3)
		goToURL($checklink);
	else
		refreshToURL(5, "$checklink&check");
stampArrayToStr($el, 'oCTS, oTS, oNTS');
$el['oParams'] = strToArray($el['oParams']);
$el['oParams2'] = strToArray($el['oParams2']);
stampArrayToStr($el['oParams2'], 'date', 1);
setPage('el', $el);
if ($el['oState'] <= 2)
{
	opDecodeCurrParams($el, $p, $p_sci, $p_api);
	if (in_array($el['cCASHINMode'], array(2, 3)))
	{
		setPage('pform', prepareSCI(
			$el['cCID'], $p, $p_sci, $el['oSum'], $el['oParams2']['memo'], $el['oID'], 
			fullURL("$checklink&check"),
			fullURL($out_link),
			valueIf(!$p_sci['hideurl'],
				fullURL(moduleToLink('balance/status'), 0)
			),
			opDecodeUserCurrParams($_currs[$el['cID']]), 
			$_cfg['Bal_ForcePayer']
		), 0);
		if (isset($_GET['pay']))
			showPage('_pform');
	}
	if (in_array($el['cCASHINMode'], array(1, 3)))
	{
		setPage('pfields', $pf = getPayFields($el['cCID']));
		setPage('pvalues', $p);
		if ($a = opCurrParamsToEdit($pf, '', $el['oState'] == 2))
			setPage('dfields', array(1 => '') + $a, 1);
		$c = getCIDs($el['cCID']);
		if (!$c[2])
			setPage('defaultbatch', 'IN' . str_pad($el['oID'], 6, '0', STR_PAD_LEFT));
	}
}

setPage('currs', $_currs);

$_GS['vmodule'] = 'balance';
showPage();

?>