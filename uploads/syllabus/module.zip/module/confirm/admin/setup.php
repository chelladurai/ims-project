<?php

$module = 'Confirm';
require_once('module/admin/setup.php');

showPage();

?>