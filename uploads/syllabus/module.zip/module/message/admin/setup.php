<?php

$module = 'Msg';
require_once('module/admin/setup.php');

showPage();

?>